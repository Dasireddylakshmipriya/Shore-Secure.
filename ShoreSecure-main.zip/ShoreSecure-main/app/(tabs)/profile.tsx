import Colors from '@/constants/colors';
import { useUserStore } from '@/store/userStore';
import { EmergencyContact } from '@/types';
import * as Haptics from 'expo-haptics';
import {
    Bell,
    ChevronRight,
    LogOut,
    Mail,
    Phone,
    Plus,
    Settings,
    Shield,
    User
} from 'lucide-react-native';
import { useState } from 'react';
import {
    Alert,
    Image,
    Platform,
    ScrollView,
    StyleSheet,
    Switch,
    Text,
    TextInput,
    TouchableOpacity,
    View
} from 'react-native';

export default function ProfileScreen() {
    const [isAddingContact, setIsAddingContact] = useState(false);
    const [contactName, setContactName] = useState('');
    const [contactPhone, setContactPhone] = useState('');
    const [contactRelationship, setContactRelationship] = useState('');

    const {
        user,
        isAuthenticated,
        login,
        logout,
        isLoading,
        addEmergencyContact,
        removeEmergencyContact,
        updatePreferences
    } = useUserStore();

    const handleLogin = () => {
        // For demo purposes, we'll use a mock login
        login('demo@shoresecure.com', 'password');
    };

    const handleLogout = () => {
        Alert.alert(
            'Logout',
            'Are you sure you want to log out?',
            [
                {
                    text: 'Cancel',
                    style: 'cancel',
                },
                {
                    text: 'Logout',
                    onPress: () => logout(),
                    style: 'destructive',
                },
            ]
        );
    };

    const handleAddContact = () => {
        if (!contactName || !contactPhone) {
            Alert.alert('Error', 'Please enter name and phone number');
            return;
        }

        const newContact: Omit<EmergencyContact, 'id'> = {
            name: contactName,
            phone: contactPhone,
            relationship: contactRelationship || 'Family',
        };

        addEmergencyContact(newContact);

        // Reset form
        setContactName('');
        setContactPhone('');
        setContactRelationship('');
        setIsAddingContact(false);

        if (Platform.OS !== 'web') {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        }
    };

    const handleRemoveContact = (contactId: string) => {
        Alert.alert(
            'Remove Contact',
            'Are you sure you want to remove this emergency contact?',
            [
                {
                    text: 'Cancel',
                    style: 'cancel',
                },
                {
                    text: 'Remove',
                    onPress: () => {
                        removeEmergencyContact(contactId);
                        if (Platform.OS !== 'web') {
                            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                        }
                    },
                    style: 'destructive',
                },
            ]
        );
    };

    const toggleNotificationSetting = (setting: 'safetyAlerts' | 'weatherUpdates' | 'tripReminders') => {
        if (!user) return;

        const currentValue = user.preferences.notificationSettings[setting];

        updatePreferences({
            notificationSettings: {
                ...user.preferences.notificationSettings,
                [setting]: !currentValue,
            }
        });

        if (Platform.OS !== 'web') {
            Haptics.selectionAsync();
        }
    };

    const renderLoginScreen = () => {
        return (
            <View style={styles.authContainer}>
                <User size={60} color={Colors.dark.primary} />
                <Text style={styles.authTitle}>Sign In to ShoreSecure</Text>
                <Text style={styles.authSubtitle}>
                    Access personalized beach recommendations, save your favorite beaches, and plan trips
                </Text>

                <TouchableOpacity
                    style={styles.loginButton}
                    onPress={handleLogin}
                    disabled={isLoading}
                >
                    {isLoading ? (
                        <Text style={styles.loginButtonText}>Signing in...</Text>
                    ) : (
                        <Text style={styles.loginButtonText}>Sign In (Demo)</Text>
                    )}
                </TouchableOpacity>
            </View>
        );
    };

    const renderEmergencyContactForm = () => {
        return (
            <View style={styles.contactForm}>
                <Text style={styles.contactFormTitle}>Add Emergency Contact</Text>

                <Text style={styles.inputLabel}>Name</Text>
                <TextInput
                    style={styles.input}
                    placeholder="Contact name"
                    placeholderTextColor={Colors.dark.textSecondary}
                    value={contactName}
                    onChangeText={setContactName}
                />

                <Text style={styles.inputLabel}>Phone Number</Text>
                <TextInput
                    style={styles.input}
                    placeholder="+91 1234567890"
                    placeholderTextColor={Colors.dark.textSecondary}
                    value={contactPhone}
                    onChangeText={setContactPhone}
                    keyboardType="phone-pad"
                />

                <Text style={styles.inputLabel}>Relationship</Text>
                <TextInput
                    style={styles.input}
                    placeholder="Family, Friend, etc."
                    placeholderTextColor={Colors.dark.textSecondary}
                    value={contactRelationship}
                    onChangeText={setContactRelationship}
                />

                <View style={styles.contactFormButtons}>
                    <TouchableOpacity
                        style={[styles.contactButton, styles.contactCancelButton]}
                        onPress={() => setIsAddingContact(false)}
                    >
                        <Text style={styles.contactCancelButtonText}>Cancel</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={[styles.contactButton, styles.contactSaveButton]}
                        onPress={handleAddContact}
                    >
                        <Text style={styles.contactSaveButtonText}>Save Contact</Text>
                    </TouchableOpacity>
                </View>
            </View>
        );
    };

    const renderProfileScreen = () => {
        if (!user) return null;

        return (
            <ScrollView contentContainerStyle={styles.profileScrollContent}>
                {/* Profile Header */}
                <View style={styles.profileHeader}>
                    {user.profilePhoto ? (
                        <Image
                            source={{ uri: user.profilePhoto }}
                            style={styles.profileImage}
                        />
                    ) : (
                        <View style={styles.profileImagePlaceholder}>
                            <User size={40} color={Colors.dark.textPrimary} />
                        </View>
                    )}

                    <View style={styles.profileInfo}>
                        <Text style={styles.profileName}>{user.name}</Text>
                        <Text style={styles.profileEmail}>{user.email}</Text>
                    </View>
                </View>

                {/* Emergency Contacts */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Emergency Contacts</Text>
                    <Text style={styles.sectionDescription}>
                        These contacts will be notified in case of an emergency
                    </Text>

                    {isAddingContact ? (
                        renderEmergencyContactForm()
                    ) : (
                        <>
                            {user.emergencyContacts.map(contact => (
                                <View key={contact.id} style={styles.contactCard}>
                                    <View style={styles.contactInfo}>
                                        <Text style={styles.contactName}>{contact.name}</Text>
                                        <Text style={styles.contactDetails}>
                                            {contact.relationship} • {contact.phone}
                                        </Text>
                                    </View>
                                    <TouchableOpacity
                                        onPress={() => handleRemoveContact(contact.id)}
                                    >
                                        <Text style={styles.removeText}>Remove</Text>
                                    </TouchableOpacity>
                                </View>
                            ))}

                            <TouchableOpacity
                                style={styles.addContactButton}
                                onPress={() => setIsAddingContact(true)}
                            >
                                <Plus size={16} color={Colors.dark.primary} />
                                <Text style={styles.addContactText}>Add Emergency Contact</Text>
                            </TouchableOpacity>
                        </>
                    )}
                </View>

                {/* Notification Settings */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Notification Settings</Text>

                    <View style={styles.settingItem}>
                        <View style={styles.settingInfo}>
                            <Text style={styles.settingTitle}>Safety Alerts</Text>
                            <Text style={styles.settingDescription}>
                                Get notified about dangerous conditions
                            </Text>
                        </View>
                        <Switch
                            value={user.preferences.notificationSettings.safetyAlerts}
                            onValueChange={() => toggleNotificationSetting('safetyAlerts')}
                            trackColor={{ false: Colors.dark.inactive, true: Colors.dark.primary }}
                            thumbColor="#fff"
                        />
                    </View>

                    <View style={styles.settingItem}>
                        <View style={styles.settingInfo}>
                            <Text style={styles.settingTitle}>Weather Updates</Text>
                            <Text style={styles.settingDescription}>
                                Receive daily weather forecasts for saved beaches
                            </Text>
                        </View>
                        <Switch
                            value={user.preferences.notificationSettings.weatherUpdates}
                            onValueChange={() => toggleNotificationSetting('weatherUpdates')}
                            trackColor={{ false: Colors.dark.inactive, true: Colors.dark.primary }}
                            thumbColor="#fff"
                        />
                    </View>

                    <View style={styles.settingItem}>
                        <View style={styles.settingInfo}>
                            <Text style={styles.settingTitle}>Trip Reminders</Text>
                            <Text style={styles.settingDescription}>
                                Get reminders about upcoming beach trips
                            </Text>
                        </View>
                        <Switch
                            value={user.preferences.notificationSettings.tripReminders}
                            onValueChange={() => toggleNotificationSetting('tripReminders')}
                            trackColor={{ false: Colors.dark.inactive, true: Colors.dark.primary }}
                            thumbColor="#fff"
                        />
                    </View>
                </View>

                {/* App Settings */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>App Settings</Text>

                    <TouchableOpacity style={styles.menuItem}>
                        <View style={styles.menuItemLeft}>
                            <Settings size={20} color={Colors.dark.textPrimary} />
                            <Text style={styles.menuItemText}>Preferences</Text>
                        </View>
                        <ChevronRight size={20} color={Colors.dark.textSecondary} />
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.menuItem}>
                        <View style={styles.menuItemLeft}>
                            <Shield size={20} color={Colors.dark.textPrimary} />
                            <Text style={styles.menuItemText}>Privacy & Security</Text>
                        </View>
                        <ChevronRight size={20} color={Colors.dark.textSecondary} />
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.menuItem}>
                        <View style={styles.menuItemLeft}>
                            <Bell size={20} color={Colors.dark.textPrimary} />
                            <Text style={styles.menuItemText}>Notifications</Text>
                        </View>
                        <ChevronRight size={20} color={Colors.dark.textSecondary} />
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.menuItem}>
                        <View style={styles.menuItemLeft}>
                            <Mail size={20} color={Colors.dark.textPrimary} />
                            <Text style={styles.menuItemText}>Contact Support</Text>
                        </View>
                        <ChevronRight size={20} color={Colors.dark.textSecondary} />
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.menuItem}>
                        <View style={styles.menuItemLeft}>
                            <Phone size={20} color={Colors.dark.textPrimary} />
                            <Text style={styles.menuItemText}>About ShoreSecure</Text>
                        </View>
                        <ChevronRight size={20} color={Colors.dark.textSecondary} />
                    </TouchableOpacity>
                </View>

                {/* Logout Button */}
                <TouchableOpacity
                    style={styles.logoutButton}
                    onPress={handleLogout}
                >
                    <LogOut size={20} color={Colors.dark.danger} />
                    <Text style={styles.logoutText}>Log Out</Text>
                </TouchableOpacity>

                <Text style={styles.versionText}>ShoreSecure v1.0.0</Text>
            </ScrollView>
        );
    };

    return (
        <View style={styles.container}>
            {isAuthenticated ? renderProfileScreen() : renderLoginScreen()}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    authContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 32,
    },
    authTitle: {
        fontSize: 24,
        fontWeight: 'bold',
        color: Colors.dark.textPrimary,
        marginTop: 24,
        marginBottom: 12,
    },
    authSubtitle: {
        fontSize: 16,
        color: Colors.dark.textSecondary,
        textAlign: 'center',
        marginBottom: 32,
        lineHeight: 24,
    },
    loginButton: {
        backgroundColor: Colors.dark.primary,
        paddingHorizontal: 32,
        paddingVertical: 16,
        borderRadius: 8,
        width: '100%',
        alignItems: 'center',
    },
    loginButtonText: {
        color: '#fff',
        fontSize: 16,
        fontWeight: 'bold',
    },
    profileScrollContent: {
        paddingBottom: 32,
    },
    profileHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 16,
        backgroundColor: Colors.dark.card,
    },
    profileImage: {
        width: 80,
        height: 80,
        borderRadius: 40,
    },
    profileImagePlaceholder: {
        width: 80,
        height: 80,
        borderRadius: 40,
        backgroundColor: Colors.dark.surface,
        justifyContent: 'center',
        alignItems: 'center',
    },
    profileInfo: {
        marginLeft: 16,
    },
    profileName: {
        fontSize: 20,
        fontWeight: 'bold',
        color: Colors.dark.textPrimary,
        marginBottom: 4,
    },
    profileEmail: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
    },
    section: {
        padding: 16,
        borderBottomWidth: 1,
        borderBottomColor: Colors.dark.border,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: Colors.dark.textPrimary,
        marginBottom: 8,
    },
    sectionDescription: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
        marginBottom: 16,
        lineHeight: 20,
    },
    contactCard: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: Colors.dark.card,
        borderRadius: 8,
        padding: 12,
        marginBottom: 12,
    },
    contactInfo: {
        flex: 1,
    },
    contactName: {
        fontSize: 16,
        fontWeight: '600',
        color: Colors.dark.textPrimary,
        marginBottom: 4,
    },
    contactDetails: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
    },
    removeText: {
        color: Colors.dark.danger,
        fontSize: 14,
        fontWeight: '600',
    },
    addContactButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 12,
        backgroundColor: 'rgba(0, 128, 128, 0.1)',
        borderRadius: 8,
        borderWidth: 1,
        borderColor: Colors.dark.primary,
        borderStyle: 'dashed',
    },
    addContactText: {
        color: Colors.dark.primary,
        fontWeight: '600',
        marginLeft: 8,
    },
    contactForm: {
        backgroundColor: Colors.dark.card,
        borderRadius: 8,
        padding: 16,
        marginTop: 8,
        marginBottom: 16,
    },
    contactFormTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        color: Colors.dark.textPrimary,
        marginBottom: 16,
    },
    inputLabel: {
        fontSize: 14,
        color: Colors.dark.textPrimary,
        marginBottom: 8,
    },
    input: {
        backgroundColor: Colors.dark.surface,
        borderRadius: 8,
        paddingHorizontal: 12,
        paddingVertical: 10,
        color: Colors.dark.textPrimary,
        marginBottom: 16,
    },
    contactFormButtons: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    contactButton: {
        flex: 1,
        paddingVertical: 12,
        borderRadius: 8,
        alignItems: 'center',
    },
    contactCancelButton: {
        backgroundColor: 'transparent',
        borderWidth: 1,
        borderColor: Colors.dark.border,
        marginRight: 8,
    },
    contactSaveButton: {
        backgroundColor: Colors.dark.primary,
        marginLeft: 8,
    },
    contactCancelButtonText: {
        color: Colors.dark.textPrimary,
    },
    contactSaveButtonText: {
        color: '#fff',
        fontWeight: 'bold',
    },
    settingItem: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 12,
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(255, 255, 255, 0.1)',
    },
    settingInfo: {
        flex: 1,
        marginRight: 16,
    },
    settingTitle: {
        fontSize: 16,
        fontWeight: '600',
        color: Colors.dark.textPrimary,
        marginBottom: 4,
    },
    settingDescription: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
    },
    menuItem: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 16,
        borderBottomWidth: 1,
        borderBottomColor: 'rgba(255, 255, 255, 0.1)',
    },
    menuItemLeft: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    menuItemText: {
        fontSize: 16,
        color: Colors.dark.textPrimary,
        marginLeft: 12,
    },
    logoutButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 16,
        marginTop: 16,
        marginHorizontal: 16,
        backgroundColor: 'rgba(244, 67, 54, 0.1)',
        borderRadius: 8,
    },
    logoutText: {
        color: Colors.dark.danger,
        fontSize: 16,
        fontWeight: 'bold',
        marginLeft: 8,
    },
    versionText: {
        textAlign: 'center',
        color: Colors.dark.textSecondary,
        fontSize: 12,
        marginTop: 16,
    },
});