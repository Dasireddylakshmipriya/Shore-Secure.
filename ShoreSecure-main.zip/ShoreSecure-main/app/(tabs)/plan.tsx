import Colors from '@/constants/colors';
import { useBeachStore } from '@/store/beachStore';
import { useUserStore } from '@/store/userStore';
import { Beach, Trip } from '@/types';
import * as Haptics from 'expo-haptics';
import { Calendar, ChevronDown, Plus, Trash2 } from 'lucide-react-native';
import React, { useState } from 'react';
import {
    Alert,
    Platform,
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View
} from 'react-native';

export default function PlanScreen() {
    const [isAddingTrip, setIsAddingTrip] = useState(false);
    const [selectedBeach, setSelectedBeach] = useState<Beach | null>(null);
    const [showBeachDropdown, setShowBeachDropdown] = useState(false);
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [activities, setActivities] = useState<string[]>([]);
    const [notes, setNotes] = useState('');

    const { user, isAuthenticated, addTrip, removeTrip } = useUserStore();
    const { beaches, fetchBeaches } = useBeachStore();

    React.useEffect(() => {
        fetchBeaches();
    }, []);

    const handleAddTrip = () => {
        if (!selectedBeach) {
            Alert.alert('Error', 'Please select a beach');
            return;
        }

        if (!startDate || !endDate) {
            Alert.alert('Error', 'Please select start and end dates');
            return;
        }

        const newTrip: Omit<Trip, 'id'> = {
            beachId: selectedBeach.id,
            startDate,
            endDate,
            activities,
            notes,
        };

        addTrip(newTrip);

        // Reset form
        setSelectedBeach(null);
        setStartDate('');
        setEndDate('');
        setActivities([]);
        setNotes('');
        setIsAddingTrip(false);

        if (Platform.OS !== 'web') {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        }
    };

    const handleRemoveTrip = (tripId: string) => {
        Alert.alert(
            'Remove Trip',
            'Are you sure you want to remove this trip?',
            [
                {
                    text: 'Cancel',
                    style: 'cancel',
                },
                {
                    text: 'Remove',
                    onPress: () => {
                        removeTrip(tripId);
                        if (Platform.OS !== 'web') {
                            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                        }
                    },
                    style: 'destructive',
                },
            ]
        );
    };

    const toggleActivity = (activity: string) => {
        if (activities.includes(activity)) {
            setActivities(activities.filter(a => a !== activity));
        } else {
            setActivities([...activities, activity]);
        }
    };

    const getBeachById = (id: string): Beach | undefined => {
        return beaches.find(beach => beach.id === id);
    };

    const renderAddTripForm = () => {
        const allActivities = [
            'Swimming', 'Sunbathing', 'Surfing', 'Snorkeling',
            'Photography', 'Walking', 'Family Activities', 'Water Sports'
        ];

        return (
            <View style={styles.formContainer}>
                <Text style={styles.formTitle}>Plan a New Trip</Text>

                {/* Beach Selection */}
                <Text style={styles.inputLabel}>Beach</Text>
                <TouchableOpacity
                    style={styles.dropdown}
                    onPress={() => setShowBeachDropdown(!showBeachDropdown)}
                >
                    <Text style={selectedBeach ? styles.dropdownText : styles.dropdownPlaceholder}>
                        {selectedBeach ? selectedBeach.name : 'Select a beach'}
                    </Text>
                    <ChevronDown size={20} color={Colors.dark.textSecondary} />
                </TouchableOpacity>

                {showBeachDropdown && (
                    <View style={styles.dropdownMenu}>
                        <ScrollView style={styles.dropdownScroll} nestedScrollEnabled>
                            {beaches.map(beach => (
                                <TouchableOpacity
                                    key={beach.id}
                                    style={styles.dropdownItem}
                                    onPress={() => {
                                        setSelectedBeach(beach);
                                        setShowBeachDropdown(false);
                                    }}
                                >
                                    <Text style={styles.dropdownItemText}>{beach.name}</Text>
                                    <Text style={styles.dropdownItemSubtext}>{beach.location}</Text>
                                </TouchableOpacity>
                            ))}
                        </ScrollView>
                    </View>
                )}

                {/* Date Selection */}
                <View style={styles.dateContainer}>
                    <View style={styles.dateField}>
                        <Text style={styles.inputLabel}>Start Date</Text>
                        <TextInput
                            style={styles.input}
                            placeholder="YYYY-MM-DD"
                            placeholderTextColor={Colors.dark.textSecondary}
                            value={startDate}
                            onChangeText={setStartDate}
                        />
                    </View>

                    <View style={styles.dateField}>
                        <Text style={styles.inputLabel}>End Date</Text>
                        <TextInput
                            style={styles.input}
                            placeholder="YYYY-MM-DD"
                            placeholderTextColor={Colors.dark.textSecondary}
                            value={endDate}
                            onChangeText={setEndDate}
                        />
                    </View>
                </View>

                {/* Activities */}
                <Text style={styles.inputLabel}>Activities</Text>
                <View style={styles.activitiesContainer}>
                    {allActivities.map(activity => (
                        <TouchableOpacity
                            key={activity}
                            style={[
                                styles.activityChip,
                                activities.includes(activity) && styles.activityChipSelected
                            ]}
                            onPress={() => toggleActivity(activity)}
                        >
                            <Text
                                style={[
                                    styles.activityChipText,
                                    activities.includes(activity) && styles.activityChipTextSelected
                                ]}
                            >
                                {activity}
                            </Text>
                        </TouchableOpacity>
                    ))}
                </View>

                {/* Notes */}
                <Text style={styles.inputLabel}>Notes</Text>
                <TextInput
                    style={[styles.input, styles.notesInput]}
                    placeholder="Add any notes about your trip..."
                    placeholderTextColor={Colors.dark.textSecondary}
                    value={notes}
                    onChangeText={setNotes}
                    multiline
                />

                {/* Buttons */}
                <View style={styles.formButtons}>
                    <TouchableOpacity
                        style={[styles.button, styles.cancelButton]}
                        onPress={() => setIsAddingTrip(false)}
                    >
                        <Text style={styles.cancelButtonText}>Cancel</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={[styles.button, styles.saveButton]}
                        onPress={handleAddTrip}
                    >
                        <Text style={styles.saveButtonText}>Save Trip</Text>
                    </TouchableOpacity>
                </View>
            </View>
        );
    };

    const renderTrips = () => {
        if (!user || !user.trips.length) {
            return (
                <View style={styles.emptyContainer}>
                    <Calendar size={40} color={Colors.dark.textSecondary} />
                    <Text style={styles.emptyText}>No trips planned yet</Text>
                    <Text style={styles.emptySubtext}>
                        Plan your beach trips to get safety alerts and recommendations
                    </Text>
                </View>
            );
        }

        return user.trips.map(trip => {
            const beach = getBeachById(trip.beachId);

            return (
                <View key={trip.id} style={styles.tripCard}>
                    <View style={styles.tripHeader}>
                        <Text style={styles.tripBeachName}>{beach?.name || 'Unknown Beach'}</Text>
                        <TouchableOpacity
                            onPress={() => handleRemoveTrip(trip.id)}
                        >
                            <Trash2 size={18} color={Colors.dark.danger} />
                        </TouchableOpacity>
                    </View>

                    <Text style={styles.tripLocation}>{beach?.location || 'Unknown Location'}</Text>

                    <View style={styles.tripDates}>
                        <Text style={styles.tripDateLabel}>From</Text>
                        <Text style={styles.tripDate}>{trip.startDate}</Text>
                        <Text style={styles.tripDateLabel}>To</Text>
                        <Text style={styles.tripDate}>{trip.endDate}</Text>
                    </View>

                    {trip.activities.length > 0 && (
                        <View style={styles.tripActivities}>
                            {trip.activities.map((activity, index) => (
                                <View key={index} style={styles.tripActivityChip}>
                                    <Text style={styles.tripActivityText}>{activity}</Text>
                                </View>
                            ))}
                        </View>
                    )}

                    {trip.notes && (
                        <Text style={styles.tripNotes}>{trip.notes}</Text>
                    )}
                </View>
            );
        });
    };

    if (!isAuthenticated) {
        return (
            <View style={styles.container}>
                <View style={styles.authPrompt}>
                    <Text style={styles.authPromptTitle}>Sign In Required</Text>
                    <Text style={styles.authPromptText}>
                        Please sign in to plan and manage your beach trips
                    </Text>
                    <TouchableOpacity
                        style={styles.authButton}
                        onPress={() => Alert.alert('Sign In', 'Navigate to the Profile tab to sign in')}
                    >
                        <Text style={styles.authButtonText}>Go to Profile</Text>
                    </TouchableOpacity>
                </View>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <ScrollView contentContainerStyle={styles.scrollContent}>
                <View style={styles.header}>
                    <Text style={styles.title}>Trip Planner</Text>
                    <Text style={styles.subtitle}>
                        Plan your beach trips and get safety recommendations
                    </Text>
                </View>

                {isAddingTrip ? (
                    renderAddTripForm()
                ) : (
                    <>
                        <TouchableOpacity
                            style={styles.addButton}
                            onPress={() => setIsAddingTrip(true)}
                        >
                            <Plus size={20} color="#fff" />
                            <Text style={styles.addButtonText}>Plan a New Trip</Text>
                        </TouchableOpacity>

                        <View style={styles.tripsContainer}>
                            <Text style={styles.sectionTitle}>Your Planned Trips</Text>
                            {renderTrips()}
                        </View>
                    </>
                )}
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    scrollContent: {
        padding: 16,
        paddingBottom: 100,
    },
    header: {
        marginBottom: 24,
    },
    title: {
        fontSize: 24,
        fontWeight: 'bold',
        color: Colors.dark.textPrimary,
        marginBottom: 8,
    },
    subtitle: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
        lineHeight: 20,
    },
    addButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Colors.dark.primary,
        borderRadius: 8,
        paddingVertical: 12,
        marginBottom: 24,
    },
    addButtonText: {
        color: '#fff',
        fontWeight: 'bold',
        marginLeft: 8,
    },
    tripsContainer: {
        marginBottom: 24,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: Colors.dark.textPrimary,
        marginBottom: 16,
    },
    emptyContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        padding: 32,
        backgroundColor: Colors.dark.card,
        borderRadius: 12,
    },
    emptyText: {
        fontSize: 16,
        fontWeight: 'bold',
        color: Colors.dark.textPrimary,
        marginTop: 16,
        marginBottom: 8,
    },
    emptySubtext: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
        textAlign: 'center',
        lineHeight: 20,
    },
    tripCard: {
        backgroundColor: Colors.dark.card,
        borderRadius: 12,
        padding: 16,
        marginBottom: 16,
    },
    tripHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 8,
    },
    tripBeachName: {
        fontSize: 18,
        fontWeight: 'bold',
        color: Colors.dark.textPrimary,
    },
    tripLocation: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
        marginBottom: 12,
    },
    tripDates: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 12,
    },
    tripDateLabel: {
        fontSize: 12,
        color: Colors.dark.textSecondary,
        marginRight: 4,
    },
    tripDate: {
        fontSize: 14,
        fontWeight: '600',
        color: Colors.dark.textPrimary,
        marginRight: 12,
    },
    tripActivities: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginBottom: 12,
        gap: 8,
    },
    tripActivityChip: {
        backgroundColor: 'rgba(30, 144, 255, 0.2)',
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 4,
    },
    tripActivityText: {
        fontSize: 12,
        color: Colors.dark.accent,
    },
    tripNotes: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
        fontStyle: 'italic',
        marginTop: 8,
    },
    formContainer: {
        backgroundColor: Colors.dark.card,
        borderRadius: 12,
        padding: 16,
        marginBottom: 24,
    },
    formTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: Colors.dark.textPrimary,
        marginBottom: 16,
    },
    inputLabel: {
        fontSize: 14,
        fontWeight: '600',
        color: Colors.dark.textPrimary,
        marginBottom: 8,
    },
    input: {
        backgroundColor: Colors.dark.surface,
        borderRadius: 8,
        paddingHorizontal: 12,
        paddingVertical: 10,
        color: Colors.dark.textPrimary,
        marginBottom: 16,
    },
    notesInput: {
        height: 100,
        textAlignVertical: 'top',
    },
    dateContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        gap: 12,
    },
    dateField: {
        flex: 1,
    },
    dropdown: {
        backgroundColor: Colors.dark.surface,
        borderRadius: 8,
        paddingHorizontal: 12,
        paddingVertical: 10,
        marginBottom: 8,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    dropdownText: {
        color: Colors.dark.textPrimary,
    },
    dropdownPlaceholder: {
        color: Colors.dark.textSecondary,
    },
    dropdownMenu: {
        backgroundColor: Colors.dark.surface,
        borderRadius: 8,
        marginBottom: 16,
        maxHeight: 200,
        borderWidth: 1,
        borderColor: Colors.dark.border,
    },
    dropdownScroll: {
        maxHeight: 200,
    },
    dropdownItem: {
        paddingHorizontal: 12,
        paddingVertical: 10,
        borderBottomWidth: 1,
        borderBottomColor: Colors.dark.border,
    },
    dropdownItemText: {
        color: Colors.dark.textPrimary,
        fontSize: 14,
    },
    dropdownItemSubtext: {
        color: Colors.dark.textSecondary,
        fontSize: 12,
        marginTop: 2,
    },
    activitiesContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginBottom: 16,
        gap: 8,
    },
    activityChip: {
        backgroundColor: Colors.dark.surface,
        paddingHorizontal: 12,
        paddingVertical: 8,
        borderRadius: 16,
        marginBottom: 8,
    },
    activityChipSelected: {
        backgroundColor: 'rgba(0, 128, 128, 0.2)',
        borderWidth: 1,
        borderColor: Colors.dark.primary,
    },
    activityChipText: {
        color: Colors.dark.textSecondary,
        fontSize: 14,
    },
    activityChipTextSelected: {
        color: Colors.dark.primary,
        fontWeight: '600',
    },
    formButtons: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 8,
    },
    button: {
        flex: 1,
        paddingVertical: 12,
        borderRadius: 8,
        alignItems: 'center',
    },
    cancelButton: {
        backgroundColor: 'transparent',
        borderWidth: 1,
        borderColor: Colors.dark.border,
        marginRight: 8,
    },
    saveButton: {
        backgroundColor: Colors.dark.primary,
        marginLeft: 8,
    },
    cancelButtonText: {
        color: Colors.dark.textPrimary,
        fontWeight: '600',
    },
    saveButtonText: {
        color: '#fff',
        fontWeight: 'bold',
    },
    authPrompt: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 32,
    },
    authPromptTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: Colors.dark.textPrimary,
        marginBottom: 12,
    },
    authPromptText: {
        fontSize: 16,
        color: Colors.dark.textSecondary,
        textAlign: 'center',
        marginBottom: 24,
        lineHeight: 22,
    },
    authButton: {
        backgroundColor: Colors.dark.primary,
        paddingHorizontal: 24,
        paddingVertical: 12,
        borderRadius: 8,
    },
    authButtonText: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 16,
    },
});