import BeachCard from '@/components/BeachCard';
import BeachDetailModal from '@/components/BeachDetailModal';
import SafetyStatusBadge from '@/components/SafetyStatusBadge';
import Colors from '@/constants/colors';
import { useBeachStore } from '@/store/beachStore';
import { Beach, SafetyStatus } from '@/types';
import * as FileSystem from 'expo-file-system';
import * as Location from 'expo-location';
import { router } from 'expo-router';
import { Compass, Filter, Layers, List, Map as MapIcon, MapPin, Search } from 'lucide-react-native';
import { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Platform, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { WebView } from 'react-native-webview';

export default function ExploreScreen() {
    const [searchQuery, setSearchQuery] = useState('');
    const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
    const [filters, setFilters] = useState<{
        safety: SafetyStatus | null;
        location: string | null;
        activities: string[];
        lifeguard: boolean;
    }>({
        safety: null,
        location: null,
        activities: [],
        lifeguard: false,
    });

    const [userLocation, setUserLocation] = useState<{ latitude: number, longitude: number } | null>(null);
    const [selectedBeach, setSelectedBeach] = useState<Beach | null>(null);
    const [showFiltersPanel, setShowFiltersPanel] = useState(false);
    const [mapReady, setMapReady] = useState(false);
    const [offlineMode, setOfflineMode] = useState(false);

    const webViewRef = useRef<WebView>(null);

    const {
        beaches,
        fetchBeaches,
        isLoading,
        selectBeach,
        fetchWeatherData
    } = useBeachStore();

    useEffect(() => {
        fetchBeaches();
        getLocationAsync();
        checkOfflineMapCache();
    }, []);

    const getLocationAsync = async () => {
        try {
            const { status } = await Location.requestForegroundPermissionsAsync();
            if (status !== 'granted') {
                console.log('Permission to access location was denied');
                return;
            }

            const location = await Location.getCurrentPositionAsync({});
            setUserLocation({
                latitude: location.coords.latitude,
                longitude: location.coords.longitude
            });
        } catch (error) {
            console.log('Error getting location:', error);
        }
    };

    const checkOfflineMapCache = async () => {
        if (Platform.OS === 'web') return;

        try {
            const cacheDir = `${FileSystem.cacheDirectory}map-tiles/`;
            const cacheInfo = await FileSystem.getInfoAsync(cacheDir);
            setOfflineMode(cacheInfo.exists && cacheInfo.isDirectory);
        } catch (error) {
            console.log('Error checking offline cache:', error);
        }
    };

    const filteredBeaches = beaches.filter(beach => {
        // Search query filter
        if (searchQuery && !beach.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
            !beach.location.toLowerCase().includes(searchQuery.toLowerCase())) {
            return false;
        }

        // Safety filter
        if (filters.safety && beach.currentSafetyStatus !== filters.safety) {
            return false;
        }

        // Location filter
        if (filters.location && !beach.location.includes(filters.location)) {
            return false;
        }

        // Activities filter
        if (filters.activities.length > 0 &&
            !filters.activities.some(activity => beach.activities.includes(activity))) {
            return false;
        }

        // Lifeguard filter
        if (filters.lifeguard && !beach.facilities.includes('Lifeguards')) {
            return false;
        }

        return true;
    });

    const handleBeachSelect = (beach: Beach) => {
        selectBeach(beach.id);
        setSelectedBeach(beach);
        fetchWeatherData(beach.id);
    };

    const handleCloseBeachDetail = () => {
        setSelectedBeach(null);
    };

    const sendMessageToMap = (message: string) => {
        if (webViewRef.current) {
            webViewRef.current.injectJavaScript(`
        (function() {
          window.receiveMessageFromRN(${JSON.stringify(message)});
          return true;
        })();
      `);
        }
    };

    const handleMapMessage = (event: any) => {
        try {
            const data = JSON.parse(event.nativeEvent.data);

            if (data.type === 'BEACH_SELECTED') {
                const beach = beaches.find(b => b.id === data.beachId);
                if (beach) {
                    handleBeachSelect(beach);
                }
            } else if (data.type === 'MAP_READY') {
                setMapReady(true);
                // Send beaches data to map
                sendMessageToMap(JSON.stringify({
                    type: 'SET_BEACHES',
                    beaches: filteredBeaches
                }));

                // Send user location to map if available
                if (userLocation) {
                    sendMessageToMap(JSON.stringify({
                        type: 'SET_USER_LOCATION',
                        location: userLocation
                    }));
                }
            } else if (data.type === 'NAVIGATION_REQUESTED') {
                // Handle external navigation request
                const { latitude, longitude, beachName } = data;
                handleExternalNavigation(latitude, longitude, beachName);
            }
        } catch (error) {
            console.log('Error parsing message from map:', error);
        }
    };

    useEffect(() => {
        if (mapReady && viewMode === 'map') {
            // Update map with filtered beaches
            sendMessageToMap(JSON.stringify({
                type: 'SET_BEACHES',
                beaches: filteredBeaches
            }));

            // Update map with filters
            sendMessageToMap(JSON.stringify({
                type: 'SET_FILTERS',
                filters
            }));
        }
    }, [filteredBeaches, filters, mapReady, viewMode]);

    useEffect(() => {
        if (mapReady && userLocation && viewMode === 'map') {
            // Update map with user location
            sendMessageToMap(JSON.stringify({
                type: 'SET_USER_LOCATION',
                location: userLocation
            }));
        }
    }, [userLocation, mapReady, viewMode]);

    const handleExternalNavigation = (latitude: number, longitude: number, beachName: string) => {
        // Different handling for different platforms
        let url = '';

        if (Platform.OS === 'ios') {
            url = `maps://app?daddr=${latitude},${longitude}&dirflg=d`;
        } else if (Platform.OS === 'android') {
            url = `google.navigation:q=${latitude},${longitude}`;
        } else {
            url = `https://www.google.com/maps/dir/?api=1&destination=${latitude},${longitude}&travelmode=driving`;
        }

        // In a real app, we would use Linking.openURL(url)
        console.log(`Opening navigation to ${beachName} at ${latitude},${longitude}`);
        alert(`Navigation would open to: ${beachName}`);
    };

    const getMapHTML = () => {
        return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <title>Beach Map</title>
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
        <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css" />
        <link rel="stylesheet" href="https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css" />
        <style>
          body {
            padding: 0;
            margin: 0;
          }
          html, body, #map {
            height: 100%;
            width: 100%;
            background-color: #121212;
          }
          .beach-popup {
            color: #333;
          }
          .beach-popup-title {
            font-weight: bold;
            margin-bottom: 5px;
          }
          .beach-popup-location {
            font-size: 12px;
            margin-bottom: 5px;
          }
          .beach-popup-status {
            display: inline-block;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 12px;
            margin-top: 5px;
          }
          .status-safe {
            background-color: rgba(76, 175, 80, 0.2);
            color: #4CAF50;
          }
          .status-moderate {
            background-color: rgba(255, 152, 0, 0.2);
            color: #FF9800;
          }
          .status-dangerous {
            background-color: rgba(244, 67, 54, 0.2);
            color: #F44336;
          }
          .beach-popup-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
          }
          .beach-popup-button {
            padding: 5px 10px;
            border-radius: 4px;
            background-color: #008080;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 12px;
          }
          .leaflet-container {
            background-color: #1E1E1E;
          }
          .leaflet-tile-pane {
            filter: grayscale(30%) invert(100%) contrast(70%) hue-rotate(180deg) brightness(95%) saturate(80%);
          }
          .leaflet-control-zoom a {
            background-color: #1E1E1E;
            color: #FFFFFF;
            border-color: #333333;
          }
          .leaflet-control-zoom a:hover {
            background-color: #333333;
          }
          .leaflet-popup-content-wrapper {
            background-color: #1E1E1E;
            color: #FFFFFF;
            border-radius: 8px;
          }
          .leaflet-popup-tip {
            background-color: #1E1E1E;
          }
          .user-location-circle {
            fill: rgba(0, 128, 255, 0.2);
            stroke: #0080FF;
            stroke-width: 2;
          }
          .user-location-marker {
            background-color: #0080FF;
            border: 2px solid white;
            border-radius: 50%;
            width: 12px;
            height: 12px;
          }
        </style>
      </head>
      <body>
        <div id="map"></div>
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
        <script src="https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js"></script>
        <script>
          // Initialize map
          const map = L.map('map').setView([15.0, 78.0], 5); // Center on India
          
          // Add dark theme tile layer
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            maxZoom: 19,
            subdomains: ['a', 'b', 'c']
          }).addTo(map);
          
          // Initialize marker cluster group
          const markers = L.markerCluster.MarkerClusterGroup({
            maxClusterRadius: 50,
            iconCreateFunction: function(cluster) {
              const count = cluster.getChildCount();
              return L.divIcon({
                html: '<div style="background-color: #008080; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; justify-content: center; align-items: center; font-weight: bold;">' + count + '</div>',
                className: 'custom-cluster-icon',
                iconSize: L.point(30, 30)
              });
            }
          });
          
          // Beach markers with custom icons
          const beachMarkers = {};
          let userLocationMarker = null;
          let userLocationCircle = null;
          
          // Create custom marker icons
          const safeIcon = L.divIcon({
            html: '<div style="background-color: #4CAF50; border-radius: 50%; width: 20px; height: 20px; border: 2px solid white;"></div>',
            className: 'custom-marker-icon',
            iconSize: [20, 20]
          });
          
          const moderateIcon = L.divIcon({
            html: '<div style="background-color: #FF9800; border-radius: 50%; width: 20px; height: 20px; border: 2px solid white;"></div>',
            className: 'custom-marker-icon',
            iconSize: [20, 20]
          });
          
          const dangerousIcon = L.divIcon({
            html: '<div style="background-color: #F44336; border-radius: 50%; width: 20px; height: 20px; border: 2px solid white;"></div>',
            className: 'custom-marker-icon',
            iconSize: [20, 20]
          });
          
          // Function to get marker icon based on safety status
          function getMarkerIcon(status) {
            switch(status) {
              case 'safe':
                return safeIcon;
              case 'moderate':
                return moderateIcon;
              case 'dangerous':
                return dangerousIcon;
              default:
                return safeIcon;
            }
          }
          
          // Function to create beach markers
          function createBeachMarkers(beaches) {
            // Clear existing markers
            markers.clearLayers();
            beachMarkers = {};
            
            beaches.forEach(beach => {
              const { id, name, location, coordinates, currentSafetyStatus } = beach;
              const { latitude, longitude } = coordinates;
              
              const marker = L.marker([latitude, longitude], {
                icon: getMarkerIcon(currentSafetyStatus || 'safe')
              });
              
              const statusClass = currentSafetyStatus ? \`status-\${currentSafetyStatus}\` : 'status-safe';
              const statusText = currentSafetyStatus 
                ? currentSafetyStatus.charAt(0).toUpperCase() + currentSafetyStatus.slice(1)
                : 'Unknown';
              
              marker.bindPopup(\`
                <div class="beach-popup">
                  <div class="beach-popup-title">\${name}</div>
                  <div class="beach-popup-location">\${location}</div>
                  <div class="beach-popup-status \${statusClass}">\${statusText}</div>
                  <div class="beach-popup-buttons">
                    <button class="beach-popup-button view-details" data-id="\${id}">View Details</button>
                    <button class="beach-popup-button navigate" data-lat="\${latitude}" data-lng="\${longitude}" data-name="\${name}">Navigate</button>
                  </div>
                </div>
              \`);
              
              marker.on('popupopen', function() {
                // Add event listeners to popup buttons
                setTimeout(() => {
                  const viewDetailsBtn = document.querySelector('.view-details[data-id="' + id + '"]');
                  const navigateBtn = document.querySelector('.navigate[data-lat="' + latitude + '"][data-lng="' + longitude + '"]');
                  
                  if (viewDetailsBtn) {
                    viewDetailsBtn.addEventListener('click', function() {
                      window.ReactNativeWebView.postMessage(JSON.stringify({
                        type: 'BEACH_SELECTED',
                        beachId: id
                      }));
                    });
                  }
                  
                  if (navigateBtn) {
                    navigateBtn.addEventListener('click', function() {
                      window.ReactNativeWebView.postMessage(JSON.stringify({
                        type: 'NAVIGATION_REQUESTED',
                        latitude,
                        longitude,
                        beachName: name
                      }));
                    });
                  }
                }, 100);
              });
              
              markers.addLayer(marker);
              beachMarkers[id] = marker;
            });
            
            map.addLayer(markers);
          }
          
          // Function to set user location
          function setUserLocation(location) {
            const { latitude, longitude } = location;
            
            // Remove existing markers
            if (userLocationMarker) {
              map.removeLayer(userLocationMarker);
            }
            if (userLocationCircle) {
              map.removeLayer(userLocationCircle);
            }
            
            // Add user location marker
            userLocationMarker = L.marker([latitude, longitude], {
              icon: L.divIcon({
                className: 'user-location-marker',
                iconSize: [12, 12]
              })
            }).addTo(map);
            
            // Add accuracy circle
            userLocationCircle = L.circle([latitude, longitude], {
              radius: 1000, // 1km radius
              className: 'user-location-circle'
            }).addTo(map);
            
            // Center map on user location
            map.setView([latitude, longitude], 10);
          }
          
          // Function to apply filters
          function applyFilters(filters) {
            // This would be implemented in a real app
            console.log('Applying filters:', filters);
          }
          
          // Communication with React Native
          window.receiveMessageFromRN = function(messageString) {
            try {
              const message = JSON.parse(messageString);
              
              switch(message.type) {
                case 'SET_BEACHES':
                  createBeachMarkers(message.beaches);
                  break;
                case 'SET_USER_LOCATION':
                  setUserLocation(message.location);
                  break;
                case 'SET_FILTERS':
                  applyFilters(message.filters);
                  break;
                default:
                  console.log('Unknown message type:', message.type);
              }
            } catch (error) {
              console.error('Error processing message:', error);
            }
          };
          
          // Notify React Native that the map is ready
          setTimeout(() => {
            window.ReactNativeWebView.postMessage(JSON.stringify({
              type: 'MAP_READY'
            }));
          }, 1000);
        </script>
      </body>
      </html>
    `;
    };

    const renderMapView = () => {
        if (Platform.OS === 'web') {
            return (
                <View style={styles.mapPlaceholder}>
                    <MapPin size={40} color={Colors.dark.primary} />
                    <Text style={styles.mapPlaceholderText}>
                        Map View
                    </Text>
                    <Text style={styles.mapPlaceholderSubtext}>
                        {filteredBeaches.length} beaches found
                    </Text>
                    <Text style={styles.mapPlaceholderSubtext}>
                        (Map view is limited on web platform)
                    </Text>
                </View>
            );
        }

        return (
            <View style={styles.mapContainer}>
                <WebView
                    ref={webViewRef}
                    originWhitelist={['*']}
                    source={{ html: getMapHTML() }}
                    style={styles.map}
                    onMessage={handleMapMessage}
                    javaScriptEnabled={true}
                    domStorageEnabled={true}
                    startInLoadingState={true}
                    renderLoading={() => (
                        <View style={styles.loadingContainer}>
                            <ActivityIndicator size="large" color={Colors.dark.primary} />
                        </View>
                    )}
                />

                {offlineMode && (
                    <View style={styles.offlineBadge}>
                        <Text style={styles.offlineBadgeText}>Offline Mode</Text>
                    </View>
                )}

                <View style={styles.mapControls}>
                    <TouchableOpacity
                        style={styles.mapControlButton}
                        onPress={getLocationAsync}
                    >
                        <Compass size={20} color={Colors.dark.textPrimary} />
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={styles.mapControlButton}
                        onPress={() => setShowFiltersPanel(!showFiltersPanel)}
                    >
                        <Layers size={20} color={Colors.dark.textPrimary} />
                    </TouchableOpacity>
                </View>
            </View>
        );
    };

    const renderListView = () => {
        return (
            <ScrollView
                style={styles.listContainer}
                contentContainerStyle={styles.listContentContainer}
                showsVerticalScrollIndicator={true}
            >
                {isLoading ? (
                    <View style={styles.loadingContainer}>
                        <ActivityIndicator size="large" color={Colors.dark.primary} />
                    </View>
                ) : (
                    filteredBeaches.length > 0 ? (
                        filteredBeaches.map(beach => (
                            <BeachCard
                                key={beach.id}
                                beach={beach}
                                onPress={() => handleBeachSelect(beach)}
                            />
                        ))
                    ) : (
                        <View style={styles.emptyContainer}>
                            <Text style={styles.emptyText}>No beaches found</Text>
                            <TouchableOpacity
                                style={styles.resetButton}
                                onPress={() => {
                                    setSearchQuery('');
                                    setFilters({ safety: null, location: null, activities: [], lifeguard: false });
                                }}
                            >
                                <Text style={styles.resetButtonText}>Reset Filters</Text>
                            </TouchableOpacity>
                        </View>
                    )
                )}
                <TouchableOpacity
                    style={[styles.resetButton, { marginTop: 16 }]}
                    onPress={() => router.push('/lost-found')}
                >
                    <Text style={styles.resetButtonText}>Go to Lost & Found</Text>
                </TouchableOpacity>

            </ScrollView>
        );
    };

    const renderFilterChips = () => {
        return (
            <View style={styles.filterChips}>
                <TouchableOpacity
                    style={[
                        styles.filterChip,
                        filters.safety === 'safe' && styles.activeFilterChip
                    ]}
                    onPress={() => setFilters(prev => ({
                        ...prev,
                        safety: prev.safety === 'safe' ? null : 'safe'
                    }))}
                >
                    <SafetyStatusBadge status="safe" size="small" />
                    <Text style={styles.filterChipText}>Safe</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={[
                        styles.filterChip,
                        filters.safety === 'moderate' && styles.activeFilterChip
                    ]}
                    onPress={() => setFilters(prev => ({
                        ...prev,
                        safety: prev.safety === 'moderate' ? null : 'moderate'
                    }))}
                >
                    <SafetyStatusBadge status="moderate" size="small" />
                    <Text style={styles.filterChipText}>Moderate</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={[
                        styles.filterChip,
                        filters.safety === 'dangerous' && styles.activeFilterChip
                    ]}
                    onPress={() => setFilters(prev => ({
                        ...prev,
                        safety: prev.safety === 'dangerous' ? null : 'dangerous'
                    }))}
                >
                    <SafetyStatusBadge status="dangerous" size="small" />
                    <Text style={styles.filterChipText}>Dangerous</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={[
                        styles.filterChip,
                        filters.activities.includes('Swimming') && styles.activeFilterChip
                    ]}
                    onPress={() => setFilters(prev => ({
                        ...prev,
                        activities: prev.activities.includes('Swimming')
                            ? prev.activities.filter(a => a !== 'Swimming')
                            : [...prev.activities, 'Swimming']
                    }))}
                >
                    <Text style={styles.filterChipText}>Swimming</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={[
                        styles.filterChip,
                        filters.lifeguard && styles.activeFilterChip
                    ]}
                    onPress={() => setFilters(prev => ({
                        ...prev,
                        lifeguard: !prev.lifeguard
                    }))}
                >
                    <Text style={styles.filterChipText}>Lifeguard</Text>
                </TouchableOpacity>
            </View>
        );
    };

    const renderFiltersPanel = () => {
        if (!showFiltersPanel) return null;

        return (
            <View style={styles.filtersPanel}>
                <Text style={styles.filtersPanelTitle}>Filters</Text>

                <Text style={styles.filtersPanelSubtitle}>Safety Status</Text>
                <View style={styles.filtersPanelRow}>
                    <TouchableOpacity
                        style={[
                            styles.filtersPanelChip,
                            filters.safety === 'safe' && styles.activeFiltersPanelChip
                        ]}
                        onPress={() => setFilters(prev => ({
                            ...prev,
                            safety: prev.safety === 'safe' ? null : 'safe'
                        }))}
                    >
                        <SafetyStatusBadge status="safe" size="small" />
                        <Text style={styles.filtersPanelChipText}>Safe</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={[
                            styles.filtersPanelChip,
                            filters.safety === 'moderate' && styles.activeFiltersPanelChip
                        ]}
                        onPress={() => setFilters(prev => ({
                            ...prev,
                            safety: prev.safety === 'moderate' ? null : 'moderate'
                        }))}
                    >
                        <SafetyStatusBadge status="moderate" size="small" />
                        <Text style={styles.filtersPanelChipText}>Moderate</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={[
                            styles.filtersPanelChip,
                            filters.safety === 'dangerous' && styles.activeFiltersPanelChip
                        ]}
                        onPress={() => setFilters(prev => ({
                            ...prev,
                            safety: prev.safety === 'dangerous' ? null : 'dangerous'
                        }))}
                    >
                        <SafetyStatusBadge status="dangerous" size="small" />
                        <Text style={styles.filtersPanelChipText}>Dangerous</Text>
                    </TouchableOpacity>
                </View>

                <Text style={styles.filtersPanelSubtitle}>Activities</Text>
                <View style={styles.filtersPanelRow}>
                    {['Swimming', 'Surfing', 'Snorkeling', 'Sunbathing'].map(activity => (
                        <TouchableOpacity
                            key={activity}
                            style={[
                                styles.filtersPanelChip,
                                filters.activities.includes(activity) && styles.activeFiltersPanelChip
                            ]}
                            onPress={() => setFilters(prev => ({
                                ...prev,
                                activities: prev.activities.includes(activity)
                                    ? prev.activities.filter(a => a !== activity)
                                    : [...prev.activities, activity]
                            }))}
                        >
                            <Text style={styles.filtersPanelChipText}>{activity}</Text>
                        </TouchableOpacity>
                    ))}
                </View>

                <Text style={styles.filtersPanelSubtitle}>Facilities</Text>
                <View style={styles.filtersPanelRow}>
                    <TouchableOpacity
                        style={[
                            styles.filtersPanelChip,
                            filters.lifeguard && styles.activeFiltersPanelChip
                        ]}
                        onPress={() => setFilters(prev => ({
                            ...prev,
                            lifeguard: !prev.lifeguard
                        }))}
                    >
                        <Text style={styles.filtersPanelChipText}>Lifeguard</Text>
                    </TouchableOpacity>
                </View>

                <TouchableOpacity
                    style={styles.resetFiltersButton}
                    onPress={() => {
                        setFilters({ safety: null, location: null, activities: [], lifeguard: false });
                        setShowFiltersPanel(false);
                    }}
                >
                    <Text style={styles.resetFiltersButtonText}>Reset All Filters</Text>
                </TouchableOpacity>
            </View>
        );
    };

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <View style={styles.searchContainer}>
                    <Search size={20} color={Colors.dark.textSecondary} style={styles.searchIcon} />
                    <TextInput
                        style={styles.searchInput}
                        placeholder="Search beaches..."
                        placeholderTextColor={Colors.dark.textSecondary}
                        value={searchQuery}
                        onChangeText={setSearchQuery}
                    />
                </View>

                <TouchableOpacity
                    style={styles.filterButton}
                    onPress={() => setShowFiltersPanel(!showFiltersPanel)}
                >
                    <Filter size={20} color={Colors.dark.textSecondary} />
                </TouchableOpacity>

                <View style={styles.viewToggle}>
                    <TouchableOpacity
                        style={[
                            styles.viewToggleButton,
                            viewMode === 'list' && styles.activeViewToggleButton
                        ]}
                        onPress={() => setViewMode('list')}
                    >
                        <List size={20} color={viewMode === 'list' ? Colors.dark.primary : Colors.dark.textSecondary} />
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={[
                            styles.viewToggleButton,
                            viewMode === 'map' && styles.activeViewToggleButton
                        ]}
                        onPress={() => setViewMode('map')}
                    >
                        <MapIcon size={20} color={viewMode === 'map' ? Colors.dark.primary : Colors.dark.textSecondary} />
                    </TouchableOpacity>
                </View>
            </View>

            {renderFilterChips()}
            {renderFiltersPanel()}

            {viewMode === 'list' ? renderListView() : renderMapView()}

            {selectedBeach && (
                <BeachDetailModal
                    beach={selectedBeach}
                    visible={!!selectedBeach}
                    onClose={handleCloseBeachDetail}
                />
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 16,
        paddingBottom: 8,
    },
    searchContainer: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Colors.dark.card,
        borderRadius: 8,
        paddingHorizontal: 12,
        height: 44,
    },
    searchIcon: {
        marginRight: 8,
    },
    searchInput: {
        flex: 1,
        color: Colors.dark.textPrimary,
        fontSize: 16,
        height: '100%',
    },
    filterButton: {
        width: 44,
        height: 44,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 8,
        backgroundColor: Colors.dark.card,
        borderRadius: 8,
    },
    viewToggle: {
        flexDirection: 'row',
        marginLeft: 8,
        backgroundColor: Colors.dark.card,
        borderRadius: 8,
        overflow: 'hidden',
    },
    viewToggleButton: {
        padding: 10,
        alignItems: 'center',
        justifyContent: 'center',
        width: 44,
    },
    activeViewToggleButton: {
        backgroundColor: 'rgba(0, 128, 128, 0.2)',
    },
    filterChips: {
        flexDirection: 'row',
        paddingHorizontal: 16,
        paddingBottom: 12,
        flexWrap: 'wrap',
        gap: 8,
    },
    filterChip: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Colors.dark.card,
        borderRadius: 16,
        paddingHorizontal: 12,
        paddingVertical: 6,
        marginRight: 8,
        gap: 4,
    },
    activeFilterChip: {
        backgroundColor: 'rgba(0, 128, 128, 0.2)',
        borderColor: Colors.dark.primary,
        borderWidth: 1,
    },
    filterChipText: {
        color: Colors.dark.textPrimary,
        fontSize: 12,
    },
    listContainer: {
        flex: 1,
    },
    listContentContainer: {
        padding: 16,
        paddingTop: 8,
        paddingBottom: 100, // Add extra padding at the bottom to ensure scrollability
    },
    mapContainer: {
        flex: 1,
        position: 'relative',
    },
    map: {
        flex: 1,
    },
    mapPlaceholder: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: Colors.dark.surface,
    },
    mapPlaceholderText: {
        color: Colors.dark.textPrimary,
        fontSize: 18,
        fontWeight: 'bold',
        marginTop: 12,
    },
    mapPlaceholderSubtext: {
        color: Colors.dark.textSecondary,
        marginTop: 8,
    },
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: 200,
    },
    emptyContainer: {
        padding: 24,
        alignItems: 'center',
    },
    emptyText: {
        color: Colors.dark.textSecondary,
        fontSize: 16,
        marginBottom: 16,
    },
    resetButton: {
        backgroundColor: Colors.dark.primary,
        paddingHorizontal: 16,
        paddingVertical: 8,
        borderRadius: 8,
    },
    resetButtonText: {
        color: '#fff',
        fontWeight: '600',
    },
    mapControls: {
        position: 'absolute',
        top: 16,
        right: 16,
        gap: 8,
    },
    mapControlButton: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: 'rgba(30, 30, 30, 0.8)',
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: Colors.dark.border,
    },
    offlineBadge: {
        position: 'absolute',
        top: 16,
        left: 16,
        backgroundColor: 'rgba(244, 67, 54, 0.8)',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 16,
    },
    offlineBadgeText: {
        color: '#fff',
        fontSize: 12,
        fontWeight: '600',
    },
    filtersPanel: {
        backgroundColor: Colors.dark.surface,
        padding: 16,
        borderBottomWidth: 1,
        borderBottomColor: Colors.dark.border,
    },
    filtersPanelTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: Colors.dark.textPrimary,
        marginBottom: 16,
    },
    filtersPanelSubtitle: {
        fontSize: 14,
        fontWeight: '600',
        color: Colors.dark.textPrimary,
        marginBottom: 8,
        marginTop: 8,
    },
    filtersPanelRow: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: 8,
        marginBottom: 8,
    },
    filtersPanelChip: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Colors.dark.card,
        borderRadius: 16,
        paddingHorizontal: 12,
        paddingVertical: 8,
        gap: 4,
    },
    activeFiltersPanelChip: {
        backgroundColor: 'rgba(0, 128, 128, 0.2)',
        borderColor: Colors.dark.primary,
        borderWidth: 1,
    },
    filtersPanelChipText: {
        color: Colors.dark.textPrimary,
        fontSize: 14,
    },
    resetFiltersButton: {
        backgroundColor: 'rgba(244, 67, 54, 0.1)',
        paddingHorizontal: 16,
        paddingVertical: 10,
        borderRadius: 8,
        alignItems: 'center',
        marginTop: 16,
    },
    resetFiltersButtonText: {
        color: Colors.dark.danger,
        fontWeight: '600',
    },
});