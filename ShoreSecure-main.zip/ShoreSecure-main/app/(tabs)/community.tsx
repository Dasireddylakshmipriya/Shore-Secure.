import Colors from '@/constants/colors';
import { useBeachStore } from '@/store/beachStore';
import { CommunityPost, useCommunityStore } from '@/store/communityStore';
import { formatDistanceToNow } from '@/utils/dateUtils';
import { Link } from 'expo-router';
import {
    AlertTriangle,
    Heart,
    MessageCircle,
    Search,
    Users
} from 'lucide-react-native';
import { useEffect, useState } from 'react';
import {
    ActivityIndicator,
    FlatList,
    Image,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View
} from 'react-native';

export default function CommunityScreen() {
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedFilter, setSelectedFilter] = useState<string | null>(null);

    const {
        posts,
        isLoading,
        fetchPosts,
        likePost
    } = useCommunityStore();

    const { beaches } = useBeachStore();

    useEffect(() => {
        fetchPosts();
    }, []);

    const getBeachName = (beachId: string) => {
        const beach = beaches.find(b => b.id === beachId);
        return beach?.name || 'Unknown Beach';
    };

    const filteredPosts = posts.filter(post => {
        // Search filter
        if (searchQuery) {
            const query = searchQuery.toLowerCase();
            const matchesContent = post.content.toLowerCase().includes(query);
            const matchesBeach = getBeachName(post.beachId).toLowerCase().includes(query);
            const matchesUser = post.userName.toLowerCase().includes(query);
            const matchesTags = post.tags.some(tag => tag.toLowerCase().includes(query));

            if (!matchesContent && !matchesBeach && !matchesUser && !matchesTags) {
                return false;
            }
        }

        // Tag filter
        if (selectedFilter) {
            if (selectedFilter === 'alerts') {
                return post.isAlert;
            } else {
                return post.tags.includes(selectedFilter);
            }
        }

        return true;
    });

    const renderPost = ({ item }: { item: CommunityPost }) => {
        const formattedTime = formatDistanceToNow(new Date(item.timestamp));
        const beachName = getBeachName(item.beachId);

        return (
            <Link href={`/community/${item.beachId}`} asChild>
                <TouchableOpacity style={[
                    styles.postContainer,
                    item.isAlert && styles.alertPostContainer
                ]}>
                    {item.isAlert && (
                        <View style={styles.alertBanner}>
                            <AlertTriangle size={16} color="#fff" />
                            <Text style={styles.alertText}>
                                {item.alertType?.toUpperCase()} ALERT
                            </Text>
                        </View>
                    )}

                    <View style={styles.postHeader}>
                        <Image
                            source={{ uri: item.userAvatar || 'https://i.pravatar.cc/150' }}
                            style={styles.avatar}
                        />
                        <View style={styles.postHeaderText}>
                            <Text style={styles.userName}>{item.userName}</Text>
                            <View style={styles.postMeta}>
                                <Text style={styles.beachName}>{beachName}</Text>
                                <Text style={styles.timestamp}> • {formattedTime}</Text>
                            </View>
                        </View>
                    </View>

                    <Text
                        style={styles.postContent}
                        numberOfLines={3}
                    >
                        {item.content}
                    </Text>

                    {item.imageUrl && (
                        <Image
                            source={{ uri: item.imageUrl }}
                            style={styles.postImage}
                            resizeMode="cover"
                        />
                    )}

                    {item.tags.length > 0 && (
                        <View style={styles.tagsContainer}>
                            {item.tags.slice(0, 3).map((tag, index) => (
                                <View key={index} style={styles.tag}>
                                    <Text style={styles.tagText}>#{tag}</Text>
                                </View>
                            ))}
                            {item.tags.length > 3 && (
                                <View style={styles.tag}>
                                    <Text style={styles.tagText}>+{item.tags.length - 3}</Text>
                                </View>
                            )}
                        </View>
                    )}

                    <View style={styles.postActions}>
                        <View style={styles.actionButton}>
                            <Heart size={18} color={Colors.dark.textSecondary} />
                            <Text style={styles.actionText}>{item.likes}</Text>
                        </View>

                        <View style={styles.actionButton}>
                            <MessageCircle size={18} color={Colors.dark.textSecondary} />
                            <Text style={styles.actionText}>{item.comments.length}</Text>
                        </View>
                    </View>
                </TouchableOpacity>
            </Link>
        );
    };

    const renderFilterChips = () => {
        const filters = [
            { id: 'alerts', label: 'Alerts' },
            { id: 'beach', label: 'Beach' },
            { id: 'swimming', label: 'Swimming' },
            { id: 'surfing', label: 'Surfing' },
            { id: 'weather', label: 'Weather' },
            { id: 'crowded', label: 'Crowded' },
        ];

        return (
            <View style={styles.filterChips}>
                {filters.map((filter) => (
                    <TouchableOpacity
                        key={filter.id}
                        style={[
                            styles.filterChip,
                            selectedFilter === filter.id && styles.activeFilterChip
                        ]}
                        onPress={() => setSelectedFilter(
                            selectedFilter === filter.id ? null : filter.id
                        )}
                    >
                        {filter.id === 'alerts' && (
                            <AlertTriangle
                                size={14}
                                color={selectedFilter === 'alerts' ? Colors.dark.warning : Colors.dark.textSecondary}
                            />
                        )}
                        <Text
                            style={[
                                styles.filterChipText,
                                selectedFilter === filter.id && styles.activeFilterChipText,
                                filter.id === 'alerts' && selectedFilter === 'alerts' && { color: Colors.dark.warning }
                            ]}
                        >
                            {filter.label}
                        </Text>
                    </TouchableOpacity>
                ))}
            </View>
        );
    };

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <View style={styles.searchContainer}>
                    <Search size={20} color={Colors.dark.textSecondary} style={styles.searchIcon} />
                    <TextInput
                        style={styles.searchInput}
                        placeholder="Search community posts..."
                        placeholderTextColor={Colors.dark.textSecondary}
                        value={searchQuery}
                        onChangeText={setSearchQuery}
                    />
                </View>
            </View>

            {renderFilterChips()}

            {isLoading ? (
                <View style={styles.loadingContainer}>
                    <ActivityIndicator size="large" color={Colors.dark.primary} />
                    <Text style={styles.loadingText}>Loading community posts...</Text>
                </View>
            ) : (
                <FlatList
                    data={filteredPosts}
                    renderItem={renderPost}
                    keyExtractor={(item) => item.id}
                    contentContainerStyle={styles.postsList}
                    showsVerticalScrollIndicator={true}
                    ListEmptyComponent={
                        <View style={styles.emptyContainer}>
                            <Users size={40} color={Colors.dark.textSecondary} />
                            <Text style={styles.emptyText}>No posts found</Text>
                            <Text style={styles.emptySubtext}>
                                {searchQuery || selectedFilter
                                    ? 'Try changing your search or filters'
                                    : 'Community posts will appear here'}
                            </Text>
                        </View>
                    }
                />
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    header: {
        padding: 16,
        paddingBottom: 8,
    },
    searchContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Colors.dark.card,
        borderRadius: 8,
        paddingHorizontal: 12,
        height: 44,
    },
    searchIcon: {
        marginRight: 8,
    },
    searchInput: {
        flex: 1,
        color: Colors.dark.textPrimary,
        fontSize: 16,
        height: '100%',
    },
    filterChips: {
        flexDirection: 'row',
        paddingHorizontal: 16,
        paddingBottom: 12,
        flexWrap: 'wrap',
        gap: 8,
    },
    filterChip: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: Colors.dark.card,
        borderRadius: 16,
        paddingHorizontal: 12,
        paddingVertical: 6,
        gap: 4,
    },
    activeFilterChip: {
        backgroundColor: 'rgba(0, 128, 128, 0.2)',
        borderColor: Colors.dark.primary,
        borderWidth: 1,
    },
    filterChipText: {
        color: Colors.dark.textPrimary,
        fontSize: 12,
    },
    activeFilterChipText: {
        color: Colors.dark.primary,
    },
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    loadingText: {
        marginTop: 16,
        color: Colors.dark.textSecondary,
    },
    postsList: {
        padding: 16,
        paddingTop: 8,
    },
    postContainer: {
        backgroundColor: Colors.dark.card,
        borderRadius: 12,
        padding: 16,
        marginBottom: 16,
    },
    alertPostContainer: {
        borderLeftWidth: 4,
        borderLeftColor: Colors.dark.warning,
    },
    alertBanner: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'rgba(255, 152, 0, 0.2)',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 4,
        marginBottom: 12,
        gap: 8,
    },
    alertText: {
        color: Colors.dark.warning,
        fontWeight: 'bold',
        fontSize: 12,
    },
    postHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 12,
    },
    avatar: {
        width: 36,
        height: 36,
        borderRadius: 18,
        marginRight: 12,
    },
    postHeaderText: {
        flex: 1,
    },
    userName: {
        fontSize: 14,
        fontWeight: '600',
        color: Colors.dark.textPrimary,
    },
    postMeta: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    beachName: {
        fontSize: 12,
        color: Colors.dark.primary,
    },
    timestamp: {
        fontSize: 12,
        color: Colors.dark.textSecondary,
    },
    postContent: {
        fontSize: 16,
        color: Colors.dark.textPrimary,
        marginBottom: 12,
        lineHeight: 22,
    },
    postImage: {
        width: '100%',
        height: 150,
        borderRadius: 8,
        marginBottom: 12,
    },
    tagsContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginBottom: 12,
        gap: 8,
    },
    tag: {
        backgroundColor: 'rgba(0, 128, 128, 0.1)',
        borderRadius: 16,
        paddingHorizontal: 10,
        paddingVertical: 4,
    },
    tagText: {
        fontSize: 12,
        color: Colors.dark.primary,
    },
    postActions: {
        flexDirection: 'row',
        borderTopWidth: 1,
        borderTopColor: Colors.dark.border,
        paddingTop: 12,
    },
    actionButton: {
        flexDirection: 'row',
        alignItems: 'center',
        marginRight: 24,
        gap: 4,
    },
    actionText: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
    },
    emptyContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        padding: 40,
    },
    emptyText: {
        fontSize: 18,
        fontWeight: 'bold',
        color: Colors.dark.textSecondary,
        marginTop: 16,
    },
    emptySubtext: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
        marginTop: 8,
        textAlign: 'center',
    },
});