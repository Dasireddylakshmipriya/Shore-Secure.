import ChatMessage from '@/components/ChatMessage';
import Colors from '@/constants/colors';
import { useBeachStore } from '@/store/beachStore';
import { useChatStore } from '@/store/chatStore';
import * as Haptics from 'expo-haptics';
import * as Speech from 'expo-speech';
import { Mic, Send, Trash2, X } from 'lucide-react-native';
import { useEffect, useRef, useState } from 'react';
import {
    ActivityIndicator,
    FlatList,
    Keyboard,
    KeyboardAvoidingView,
    Platform,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View
} from 'react-native';

export default function ChatScreen() {
    const [message, setMessage] = useState('');
    const [isRecording, setIsRecording] = useState(false);
    const [isKeyboardVisible, setIsKeyboardVisible] = useState(false);
    const flatListRef = useRef<FlatList>(null);
    const inputRef = useRef<TextInput>(null);

    const { messages, sendMessage, clearChat, isLoading } = useChatStore();
    const { beaches } = useBeachStore();

    useEffect(() => {
        const keyboardDidShowListener = Keyboard.addListener(
            'keyboardDidShow',
            () => {
                setIsKeyboardVisible(true);
                scrollToBottom();
            }
        );
        const keyboardDidHideListener = Keyboard.addListener(
            'keyboardDidHide',
            () => {
                setIsKeyboardVisible(false);
            }
        );

        return () => {
            keyboardDidShowListener.remove();
            keyboardDidHideListener.remove();
        };
    }, []);

    useEffect(() => {
        // Scroll to bottom when new messages arrive
        if (messages.length > 0) {
            scrollToBottom();
        }
    }, [messages]);

    const scrollToBottom = () => {
        setTimeout(() => {
            if (flatListRef.current) {
                flatListRef.current.scrollToEnd({ animated: true });
            }
        }, 100);
    };

    const handleSend = async () => {
        if (message.trim() === '') return;

        const trimmedMessage = message.trim();
        setMessage('');

        if (Platform.OS !== 'web') {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        }

        await sendMessage(trimmedMessage);
        scrollToBottom();
    };

    const handleClearChat = () => {
        if (Platform.OS !== 'web') {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        }

        clearChat();
    };

    const handleStartRecording = async () => {
        // In a real app, we would use voice recognition
        // For now, we'll just simulate it
        if (Platform.OS !== 'web') {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        }

        setIsRecording(true);

        // Simulate recording for 2 seconds
        setTimeout(() => {
            setIsRecording(false);

            // Set a random beach query
            const randomBeach = beaches[Math.floor(Math.random() * beaches.length)];
            const queries = [
                `Is ${randomBeach.name} safe for swimming today?`,
                `What's the weather like at ${randomBeach.name}?`,
                `How are the waves at ${randomBeach.name}?`
            ];

            setMessage(queries[Math.floor(Math.random() * queries.length)]);

            if (Platform.OS !== 'web') {
                Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            }

            // Focus the input
            if (inputRef.current) {
                inputRef.current.focus();
            }
        }, 2000);
    };

    const handleStopRecording = () => {
        if (Platform.OS !== 'web') {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        }

        setIsRecording(false);
    };

    const handleSpeakMessage = (text: string) => {
        if (Platform.OS === 'web') return;

        Speech.speak(text, {
            language: 'en',
            pitch: 1.0,
            rate: 0.9,
        });
    };

    const renderSuggestions = () => {
        const suggestions = [
            "Is Calangute Beach safe today?",
            "Best beaches for families in Goa?",
            "What should I do during a rip current?",
            "Beach safety tips for children",
            "Weather forecast for Kovalam Beach"
        ];

        return (
            <View style={styles.suggestionsContainer}>
                <Text style={styles.suggestionsTitle}>Suggested Questions</Text>
                <View style={styles.suggestionChips}>
                    {suggestions.map((suggestion, index) => (
                        <TouchableOpacity
                            key={index}
                            style={styles.suggestionChip}
                            onPress={() => {
                                setMessage(suggestion);
                                if (inputRef.current) {
                                    inputRef.current.focus();
                                }
                                if (Platform.OS !== 'web') {
                                    Haptics.selectionAsync();
                                }
                            }}
                        >
                            <Text style={styles.suggestionText} numberOfLines={1}>
                                {suggestion}
                            </Text>
                        </TouchableOpacity>
                    ))}
                </View>
            </View>
        );
    };

    return (
        <KeyboardAvoidingView
            style={styles.container}
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
            keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
        >
            <View style={styles.header}>
                <Text style={styles.headerTitle}>ShoreBot</Text>
                <Text style={styles.headerSubtitle}>Your beach safety assistant</Text>

                <TouchableOpacity
                    style={styles.clearButton}
                    onPress={handleClearChat}
                >
                    <Trash2 size={16} color={Colors.dark.textSecondary} />
                    <Text style={styles.clearButtonText}>Clear Chat</Text>
                </TouchableOpacity>
            </View>

            <FlatList
                ref={flatListRef}
                data={messages}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                    <ChatMessage
                        message={item}
                        onSpeakMessage={handleSpeakMessage}
                    />
                )}
                contentContainerStyle={styles.messagesContainer}
                onLayout={() => flatListRef.current?.scrollToEnd({ animated: false })}
                ListEmptyComponent={
                    <View style={styles.emptyContainer}>
                        <Text style={styles.emptyText}>No messages yet</Text>
                    </View>
                }
                ListFooterComponent={
                    isLoading ? (
                        <View style={styles.loadingContainer}>
                            <ActivityIndicator color={Colors.dark.primary} size="small" />
                            <Text style={styles.loadingText}>ShoreBot is thinking...</Text>
                        </View>
                    ) : null
                }
            />

            {messages.length <= 1 && !isKeyboardVisible && renderSuggestions()}

            <View style={styles.inputContainer}>
                <TextInput
                    ref={inputRef}
                    style={styles.input}
                    placeholder="Ask ShoreBot about beach safety..."
                    placeholderTextColor={Colors.dark.textSecondary}
                    value={message}
                    onChangeText={setMessage}
                    multiline
                    maxLength={500}
                    onSubmitEditing={handleSend}
                />

                {message.trim() !== '' ? (
                    <TouchableOpacity
                        style={styles.sendButton}
                        onPress={handleSend}
                        disabled={isLoading}
                    >
                        <Send size={20} color="#fff" />
                    </TouchableOpacity>
                ) : (
                    <TouchableOpacity
                        style={[
                            styles.micButton,
                            isRecording && styles.recordingButton
                        ]}
                        onPress={isRecording ? handleStopRecording : handleStartRecording}
                        disabled={isLoading}
                    >
                        {isRecording ? (
                            <X size={20} color="#fff" />
                        ) : (
                            <Mic size={20} color="#fff" />
                        )}
                    </TouchableOpacity>
                )}
            </View>

            {isRecording && (
                <View style={styles.recordingIndicator}>
                    <View style={styles.recordingDot} />
                    <Text style={styles.recordingText}>Listening...</Text>
                </View>
            )}
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    header: {
        padding: 16,
        borderBottomWidth: 1,
        borderBottomColor: Colors.dark.border,
        alignItems: 'center',
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: Colors.dark.textPrimary,
    },
    headerSubtitle: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
        marginTop: 4,
    },
    clearButton: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 8,
        padding: 6,
    },
    clearButtonText: {
        color: Colors.dark.textSecondary,
        fontSize: 12,
        marginLeft: 4,
    },
    messagesContainer: {
        paddingVertical: 16,
        flexGrow: 1,
    },
    inputContainer: {
        flexDirection: 'row',
        padding: 12,
        borderTopWidth: 1,
        borderTopColor: Colors.dark.border,
        backgroundColor: Colors.dark.surface,
    },
    input: {
        flex: 1,
        backgroundColor: Colors.dark.card,
        borderRadius: 20,
        paddingHorizontal: 16,
        paddingVertical: 10,
        color: Colors.dark.textPrimary,
        maxHeight: 100,
    },
    sendButton: {
        width: 44,
        height: 44,
        borderRadius: 22,
        backgroundColor: Colors.dark.primary,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 8,
    },
    micButton: {
        width: 44,
        height: 44,
        borderRadius: 22,
        backgroundColor: Colors.dark.accent,
        justifyContent: 'center',
        alignItems: 'center',
        marginLeft: 8,
    },
    recordingButton: {
        backgroundColor: Colors.dark.danger,
    },
    emptyContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 24,
    },
    emptyText: {
        color: Colors.dark.textSecondary,
        fontStyle: 'italic',
    },
    loadingContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 16,
    },
    loadingText: {
        color: Colors.dark.textSecondary,
        marginLeft: 8,
        fontSize: 14,
    },
    suggestionsContainer: {
        padding: 16,
        backgroundColor: Colors.dark.surface,
        borderTopWidth: 1,
        borderTopColor: Colors.dark.border,
    },
    suggestionsTitle: {
        fontSize: 14,
        fontWeight: '600',
        color: Colors.dark.textPrimary,
        marginBottom: 8,
    },
    suggestionChips: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: 8,
    },
    suggestionChip: {
        backgroundColor: Colors.dark.card,
        paddingHorizontal: 12,
        paddingVertical: 8,
        borderRadius: 16,
        marginBottom: 8,
        maxWidth: '48%',
    },
    suggestionText: {
        color: Colors.dark.accent,
        fontSize: 13,
    },
    recordingIndicator: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 12,
        backgroundColor: 'rgba(244, 67, 54, 0.1)',
    },
    recordingDot: {
        width: 12,
        height: 12,
        borderRadius: 6,
        backgroundColor: Colors.dark.danger,
        marginRight: 8,
    },
    recordingText: {
        color: Colors.dark.danger,
        fontWeight: '600',
    },
});