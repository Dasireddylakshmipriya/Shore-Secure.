import BeachCard from '@/components/BeachCard';
import LostItemCard from '@/components/LostItemCard';
import SOSButton from '@/components/SOSButton';
import Colors from '@/constants/colors';
import { useBeachStore } from '@/store/beachStore';
import { useLostItemStore } from '@/store/lostItemStore';
import { useUserStore } from '@/store/userStore';
import * as Location from 'expo-location';
import { useRouter } from 'expo-router';
import { AlertTriangle, Info, MapPin, Shield, Sun, Waves } from 'lucide-react-native';
import { useEffect, useState } from 'react';
import {
    ActivityIndicator,
    Dimensions,
    Image,
    RefreshControl,
    ScrollView,
    StyleSheet,
    Text,
    TouchableOpacity,
    View
} from 'react-native';

import { LinearGradient } from 'expo-linear-gradient'; // ✅ Correct source


const { width } = Dimensions.get('window');

export default function HomeScreen() {
    const router = useRouter();
    const [refreshing, setRefreshing] = useState(false);
    const [userLocation, setUserLocation] = useState<{ latitude: number, longitude: number } | null>(null);
    const [locationError, setLocationError] = useState<string | null>(null);

    const {
        beaches,
        nearbyBeaches,
        fetchBeaches,
        fetchNearbyBeaches,
        isLoading,
        offlineMode,
        setOfflineMode
    } = useBeachStore();

    const { user, isAuthenticated } = useUserStore();
    const { lostItems, fetchLostItems } = useLostItemStore();

    useEffect(() => {
        fetchBeaches();
        getLocationAsync();
        fetchLostItems();
        checkNetworkStatus();
    }, []);

    const checkNetworkStatus = () => {
        const isOffline = false;
        setOfflineMode(isOffline);
    };

    const getLocationAsync = async () => {
        try {
            const { status } = await Location.requestForegroundPermissionsAsync();
            if (status !== 'granted') {
                setLocationError('Permission to access location was denied');
                setUserLocation({ latitude: 15.5491, longitude: 73.7632 });
                fetchNearbyBeaches(15.5491, 73.7632, 50);
                return;
            }

            const location = await Location.getCurrentPositionAsync({});
            const coords = {
                latitude: location.coords.latitude,
                longitude: location.coords.longitude
            };
            setUserLocation(coords);
            fetchNearbyBeaches(coords.latitude, coords.longitude, 50);
        } catch (error) {
            console.error('Error getting location:', error);
            setLocationError('Error getting location');
            setUserLocation({ latitude: 15.5491, longitude: 73.7632 });
            fetchNearbyBeaches(15.5491, 73.7632, 50);
        }
    };

    const onRefresh = async () => {
        setRefreshing(true);
        await fetchBeaches();
        if (userLocation) {
            await fetchNearbyBeaches(userLocation.latitude, userLocation.longitude, 50);
        }
        await fetchLostItems();
        setRefreshing(false);
    };

    const getSavedBeaches = () => {
        if (!user || !user.savedBeaches || !user.savedBeaches.length) return [];
        return beaches.filter(beach => user.savedBeaches.includes(beach.id));
    };

    const getRecommendedBeaches = () => {
        return beaches.filter(beach => beach.currentSafetyStatus === 'safe').slice(0, 5);
    };

    const getRecentLostItems = () => {
        return lostItems
            .filter(item => item.status === 'lost' || item.status === 'found')
            .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
            .slice(0, 3);
    };

    const getLocationName = () => {
        if (locationError) return 'Location unavailable';
        if (!userLocation) return 'Getting location...';
        return 'Goa, India';
    };

    return (
        <View style={styles.container}>
            <ScrollView
                contentContainerStyle={styles.scrollContent}
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh}
                        tintColor={Colors.dark.primary}
                        colors={[Colors.dark.primary]}
                    />
                }
                showsVerticalScrollIndicator={false}
            >
                {/* Modern Header with Gradient */}
                <View style={styles.headerContainer}>
                    <LinearGradient
                        colors={['rgba(59, 130, 246, 0.1)', 'transparent']}
                        style={styles.headerGradient}
                    />
                    <View style={styles.header}>
                        <View style={styles.topRow}>
                            <View style={styles.locationContainer}>
                                <View style={styles.locationIcon}>
                                    <MapPin size={16} color={Colors.dark.primary} />
                                </View>
                                <Text style={styles.locationText}>{getLocationName()}</Text>
                                {offlineMode && (
                                    <View style={styles.offlineBadge}>
                                        <Text style={styles.offlineBadgeText}>Offline</Text>
                                    </View>
                                )}
                            </View>
                        </View>

                        <View style={styles.welcomeContainer}>
                            <Text style={styles.welcomeText}>
                                {isAuthenticated ? `Hello, ${user?.name.split(' ')[0]}! 👋` : 'Welcome to ShoreSecure'}
                            </Text>
                            <Text style={styles.welcomeSubtext}>
                                Stay safe and enjoy your beach experience
                            </Text>
                        </View>

                        {/* Modern Logo Card */}
                        <View style={styles.logoCard}>
                            <Image
                                source={{ uri: 'https://images.unsplash.com/photo-1559494007-9f5847c49d94?q=80&w=1000' }}
                                style={styles.logoBackground}
                                resizeMode="cover"
                            />
                            <View style={styles.logoOverlay}>
                                <View style={styles.logoContainer}>
                                    <Shield size={32} color="#fff" />
                                    <Text style={styles.logoText}>ShoreSecure</Text>
                                </View>
                                <View style={styles.statsContainer}>
                                    <View style={styles.statItem}>
                                        <Waves size={16} color="#fff" />
                                        <Text style={styles.statText}>{beaches.length} Beaches</Text>
                                    </View>
                                    <View style={styles.statItem}>
                                        <Sun size={16} color="#fff" />
                                        <Text style={styles.statText}>Live Updates</Text>
                                    </View>
                                </View>
                            </View>
                        </View>
                    </View>
                </View>

                {/* Modern Safety Alert */}
                <View style={styles.alertContainer}>
                    <View style={styles.alertBanner}>
                        <View style={styles.alertIcon}>
                            <AlertTriangle size={18} color="#fff" />
                        </View>
                        <View style={styles.alertContent}>
                            <Text style={styles.alertTitle}>Safety Alert</Text>
                            <Text style={styles.alertText}>
                                High UV index expected today. Use sunscreen and stay hydrated.
                            </Text>
                        </View>
                    </View>
                </View>

                {/* Nearby Beaches Section */}
                <View style={styles.section}>
                    <View style={styles.sectionHeader}>
                        <View>
                            <Text style={styles.sectionTitle}>Nearby Beaches</Text>
                            <Text style={styles.sectionSubtitle}>Discover beaches around you</Text>
                        </View>
                        <TouchableOpacity
                            style={styles.seeAllButton}
                            onPress={() => router.push('/explore')}
                        >
                            <Text style={styles.seeAllText}>See All</Text>
                        </TouchableOpacity>
                    </View>

                    {isLoading ? (
                        <View style={styles.loadingContainer}>
                            <ActivityIndicator color={Colors.dark.primary} size="large" />
                            <Text style={styles.loadingText}>Finding nearby beaches...</Text>
                        </View>
                    ) : nearbyBeaches.length > 0 ? (
                        <ScrollView
                            horizontal
                            showsHorizontalScrollIndicator={false}
                            contentContainerStyle={styles.horizontalScrollContent}
                        >
                            {nearbyBeaches.map(beach => (
                                <BeachCard
                                    key={beach.id}
                                    beach={beach}
                                    compact
                                    onPress={() => router.push(`/beach/${beach.id}`)}
                                />
                            ))}
                        </ScrollView>
                    ) : (
                        <View style={styles.modernEmptyState}>
                            <View style={styles.emptyIcon}>
                                <Info size={24} color={Colors.dark.primary} />
                            </View>
                            <Text style={styles.emptyTitle}>No beaches found nearby</Text>
                            <Text style={styles.emptySubtitle}>Try refreshing your location or explore all beaches</Text>
                            <TouchableOpacity
                                style={styles.modernActionButton}
                                onPress={getLocationAsync}
                            >
                                <Text style={styles.modernActionButtonText}>Refresh Location</Text>
                            </TouchableOpacity>
                        </View>
                    )}
                </View>

                {/* Recent Lost & Found Section */}
                <View style={styles.section}>
                    <View style={styles.sectionHeader}>
                        <View>
                            <Text style={styles.sectionTitle}>Lost & Found</Text>
                            <Text style={styles.sectionSubtitle}>Recent community reports</Text>
                        </View>
                        <TouchableOpacity
                            style={styles.seeAllButton}
                            onPress={() => router.push('/lost-found')}
                        >
                            <Text style={styles.seeAllText}>See All</Text>
                        </TouchableOpacity>
                    </View>

                    {getRecentLostItems().length > 0 ? (
                        <ScrollView
                            horizontal
                            showsHorizontalScrollIndicator={false}
                            contentContainerStyle={styles.horizontalScrollContent}
                        >
                            {getRecentLostItems().map(item => (
                                <LostItemCard
                                    key={item.id}
                                    item={item}
                                    compact
                                    onPress={() => router.push(`/lost-found/item/${item.id}`)}
                                />
                            ))}
                        </ScrollView>
                    ) : (
                        <View style={styles.modernEmptyState}>
                            <View style={styles.emptyIcon}>
                                <Info size={24} color={Colors.dark.primary} />
                            </View>
                            <Text style={styles.emptyTitle}>No recent reports</Text>
                            <Text style={styles.emptySubtitle}>Help the community by reporting lost or found items</Text>
                            <TouchableOpacity
                                style={styles.modernActionButton}
                                onPress={() => router.push('/lost-found/report')}
                            >
                                <Text style={styles.modernActionButtonText}>Report an Item</Text>
                            </TouchableOpacity>
                        </View>
                    )}
                </View>

                {/* Saved Beaches Section */}
                {isAuthenticated && (
                    <View style={styles.section}>
                        <View style={styles.sectionHeader}>
                            <View>
                                <Text style={styles.sectionTitle}>Your Favorites</Text>
                                <Text style={styles.sectionSubtitle}>Your saved beaches</Text>
                            </View>
                            <TouchableOpacity
                                style={styles.seeAllButton}
                                onPress={() => router.push('/profile')}
                            >
                                <Text style={styles.seeAllText}>See All</Text>
                            </TouchableOpacity>
                        </View>

                        {getSavedBeaches().length > 0 ? (
                            <ScrollView
                                horizontal
                                showsHorizontalScrollIndicator={false}
                                contentContainerStyle={styles.horizontalScrollContent}
                            >
                                {getSavedBeaches().map(beach => (
                                    <BeachCard
                                        key={beach.id}
                                        beach={beach}
                                        compact
                                        onPress={() => router.push(`/beach/${beach.id}`)}
                                    />
                                ))}
                            </ScrollView>
                        ) : (
                            <View style={styles.modernEmptyState}>
                                <View style={styles.emptyIcon}>
                                    <Info size={24} color={Colors.dark.primary} />
                                </View>
                                <Text style={styles.emptyTitle}>No saved beaches yet</Text>
                                <Text style={styles.emptySubtitle}>Save your favorite beaches for quick access</Text>
                                <TouchableOpacity
                                    style={styles.modernActionButton}
                                    onPress={() => router.push('/explore')}
                                >
                                    <Text style={styles.modernActionButtonText}>Explore Beaches</Text>
                                </TouchableOpacity>
                            </View>
                        )}
                    </View>
                )}

                {/* Recommended Beaches Section */}
                <View style={styles.section}>
                    <View style={styles.sectionHeader}>
                        <View>
                            <Text style={styles.sectionTitle}>Recommended</Text>
                            <Text style={styles.sectionSubtitle}>Safe beaches for you</Text>
                        </View>
                        <TouchableOpacity
                            style={styles.seeAllButton}
                            onPress={() => router.push('/explore')}
                        >
                            <Text style={styles.seeAllText}>See All</Text>
                        </TouchableOpacity>
                    </View>

                    <View style={styles.recommendedContainer}>
                        {getRecommendedBeaches().slice(0, 3).map(beach => (
                            <BeachCard
                                key={beach.id}
                                beach={beach}
                                onPress={() => router.push(`/beach/${beach.id}`)}
                            />
                        ))}
                    </View>
                </View>

                {/* Modern Info Section */}
                <View style={styles.modernInfoSection}>
                    <Image
                        source={{ uri: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1000' }}
                        style={styles.infoImage}
                        resizeMode="cover"
                    />
                    <LinearGradient
                        colors={['transparent', 'rgba(0,0,0,0.8)']}
                        style={styles.infoGradient}
                    />
                    <View style={styles.infoContent}>
                        <Text style={styles.infoTitle}>Need Help?</Text>
                        <Text style={styles.infoText}>
                            Ask ShoreBot for instant beach safety information and recommendations
                        </Text>
                        <TouchableOpacity
                            style={styles.modernInfoButton}
                            onPress={() => router.push('/chat')}
                        >
                            <Text style={styles.infoButtonText}>Chat with ShoreBot</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </ScrollView>

            <SOSButton />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.dark.background,
    },
    scrollContent: {
        paddingBottom: 100,
    },
    headerContainer: {
        position: 'relative',
        paddingBottom: 8,
    },
    headerGradient: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: 200,
    },
    header: {
        padding: 20,
        paddingTop: 12,
    },
    topRow: {
        marginBottom: 16,
    },
    locationContainer: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    locationIcon: {
        width: 28,
        height: 28,
        borderRadius: 14,
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 8,
    },
    locationText: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
        fontWeight: '500',
        flex: 1,
    },
    offlineBadge: {
        backgroundColor: Colors.dark.danger,
        paddingHorizontal: 8,
        paddingVertical: 4,
        borderRadius: 12,
    },
    offlineBadgeText: {
        color: '#fff',
        fontSize: 10,
        fontWeight: '600',
    },
    welcomeContainer: {
        marginBottom: 20,
    },
    welcomeText: {
        fontSize: 28,
        fontWeight: '700',
        color: Colors.dark.textPrimary,
        marginBottom: 4,
    },
    welcomeSubtext: {
        fontSize: 16,
        color: Colors.dark.textSecondary,
        fontWeight: '400',
    },
    logoCard: {
        height: 140,
        borderRadius: 16,
        overflow: 'hidden',
        position: 'relative',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
        elevation: 4,
    },
    logoBackground: {
        ...StyleSheet.absoluteFillObject,
    },
    logoOverlay: {
        ...StyleSheet.absoluteFillObject,
        backgroundColor: 'rgba(0,0,0,0.4)',
        padding: 20,
        justifyContent: 'space-between',
    },
    logoContainer: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    logoText: {
        fontSize: 24,
        fontWeight: '700',
        color: '#fff',
        marginLeft: 12,
    },
    statsContainer: {
        flexDirection: 'row',
        gap: 20,
    },
    statItem: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    statText: {
        color: '#fff',
        fontSize: 12,
        fontWeight: '500',
        marginLeft: 6,
    },
    alertContainer: {
        paddingHorizontal: 20,
        marginBottom: 8,
    },
    alertBanner: {
        backgroundColor: Colors.dark.warning,
        flexDirection: 'row',
        alignItems: 'flex-start',
        padding: 16,
        borderRadius: 12,
        shadowColor: Colors.dark.warning,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 4,
        elevation: 3,
    },
    alertIcon: {
        width: 36,
        height: 36,
        borderRadius: 18,
        backgroundColor: 'rgba(255,255,255,0.2)',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 12,
    },
    alertContent: {
        flex: 1,
    },
    alertTitle: {
        color: '#fff',
        fontSize: 16,
        fontWeight: '600',
        marginBottom: 4,
    },
    alertText: {
        color: '#fff',
        fontSize: 14,
        opacity: 0.9,
        lineHeight: 20,
    },
    section: {
        marginBottom: 32,
        paddingHorizontal: 20,
    },
    sectionHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: 16,
    },
    sectionTitle: {
        fontSize: 22,
        fontWeight: '700',
        color: Colors.dark.textPrimary,
        marginBottom: 2,
    },
    sectionSubtitle: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
        fontWeight: '400',
    },
    seeAllButton: {
        paddingHorizontal: 12,
        paddingVertical: 6,
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        borderRadius: 8,
    },
    seeAllText: {
        fontSize: 14,
        color: Colors.dark.primary,
        fontWeight: '600',
    },
    loadingContainer: {
        alignItems: 'center',
        padding: 32,
    },
    loadingText: {
        color: Colors.dark.textSecondary,
        marginTop: 12,
        fontSize: 14,
    },
    horizontalScrollContent: {
        paddingRight: 20,
    },
    modernEmptyState: {
        alignItems: 'center',
        padding: 32,
        backgroundColor: Colors.dark.card,
        borderRadius: 16,
        borderWidth: 1,
        borderColor: 'rgba(255,255,255,0.05)',
    },
    emptyIcon: {
        width: 48,
        height: 48,
        borderRadius: 24,
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 16,
    },
    emptyTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: Colors.dark.textPrimary,
        marginBottom: 8,
        textAlign: 'center',
    },
    emptySubtitle: {
        fontSize: 14,
        color: Colors.dark.textSecondary,
        textAlign: 'center',
        lineHeight: 20,
        marginBottom: 20,
    },
    modernActionButton: {
        paddingHorizontal: 24,
        paddingVertical: 12,
        backgroundColor: Colors.dark.primary,
        borderRadius: 12,
        shadowColor: Colors.dark.primary,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 4,
        elevation: 3,
    },
    modernActionButtonText: {
        color: '#fff',
        fontWeight: '600',
        fontSize: 14,
    },
    recommendedContainer: {
        gap: 12,
    },
    modernInfoSection: {
        margin: 20,
        borderRadius: 16,
        overflow: 'hidden',
        height: 180,
        position: 'relative',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
        elevation: 4,
    },
    infoImage: {
        width: '100%',
        height: '100%',
    },
    infoGradient: {
        ...StyleSheet.absoluteFillObject,
    },
    infoContent: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        padding: 20,
    },
    infoTitle: {
        fontSize: 20,
        fontWeight: '700',
        color: '#fff',
        marginBottom: 8,
    },
    infoText: {
        fontSize: 14,
        color: '#fff',
        lineHeight: 20,
        marginBottom: 16,
        opacity: 0.9,
    },
    modernInfoButton: {
        backgroundColor: 'rgba(255,255,255,0.2)',
        paddingHorizontal: 20,
        paddingVertical: 12,
        borderRadius: 12,
        alignSelf: 'flex-start',
        borderWidth: 1,
        borderColor: 'rgba(255,255,255,0.3)',
    },
    infoButtonText: {
        color: '#fff',
        fontWeight: '600',
        fontSize: 14,
    },
});