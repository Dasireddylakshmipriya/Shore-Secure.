import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

// Types for community posts
export interface CommunityPost {
    id: string;
    beachId: string;
    userId: string;
    userName: string;
    userAvatar?: string;
    content: string;
    imageUrl?: string;
    timestamp: string;
    likes: number;
    isAlert: boolean;
    alertType?: 'riptide' | 'jellyfish' | 'pollution' | 'crowded' | 'other';
    tags: string[];
    comments: CommunityComment[];
}

export interface CommunityComment {
    id: string;
    postId: string;
    userId: string;
    userName: string;
    content: string;
    timestamp: string;
}

interface CommunityState {
    posts: CommunityPost[];
    isLoading: boolean;
    error: string | null;

    // Actions
    fetchPosts: (beachId?: string) => Promise<void>;
    addPost: (post: Omit<CommunityPost, 'id' | 'timestamp' | 'likes' | 'comments'>) => Promise<void>;
    likePost: (postId: string) => void;
    addComment: (comment: Omit<CommunityComment, 'id' | 'timestamp'>) => Promise<void>;
    reportPost: (postId: string, reason: string) => Promise<void>;
    deletePost: (postId: string) => Promise<void>;
}

// Mock user data
const currentUser = {
    id: 'user123',
    name: 'Beach Explorer',
    avatar: 'https://i.pravatar.cc/150?img=3',
};

// Generate a mock post
const generateMockPost = (beachId: string, index: number): CommunityPost => {
    const isAlert = index % 5 === 0;
    const alertTypes = ['riptide', 'jellyfish', 'pollution', 'crowded', 'other'] as const;

    return {
        id: `post-${beachId}-${index}`,
        beachId,
        userId: `user${index % 5 + 1}`,
        userName: `Beach User ${index % 5 + 1}`,
        userAvatar: `https://i.pravatar.cc/150?img=${index % 10 + 1}`,
        content: isAlert
            ? `ALERT: ${alertTypes[index % 5]} spotted at the north end of the beach. Be careful!`
            : `This is a great day at the beach! The water is ${index % 2 === 0 ? 'warm' : 'refreshing'} and the crowd is ${index % 3 === 0 ? 'light' : 'moderate'}.`,
        imageUrl: index % 3 === 0 ? `https://source.unsplash.com/random/300x200?beach,${index}` : undefined,
        timestamp: new Date(Date.now() - index * 3600000).toISOString(),
        likes: Math.floor(Math.random() * 50),
        isAlert,
        alertType: isAlert ? alertTypes[index % 5] : undefined,
        tags: isAlert
            ? [alertTypes[index % 5]]
            : ['beach', 'vacation', 'sunny', 'swimming'].slice(0, (index % 4) + 1),
        comments: Array(Math.floor(Math.random() * 3)).fill(0).map((_, i) => ({
            id: `comment-${beachId}-${index}-${i}`,
            postId: `post-${beachId}-${index}`,
            userId: `user${(index + i) % 5 + 2}`,
            userName: `Beach Commenter ${(index + i) % 5 + 2}`,
            content: `This is comment #${i + 1} on this post. ${i % 2 === 0 ? 'Thanks for sharing!' : 'Great information!'}`,
            timestamp: new Date(Date.now() - (index * 3600000) - (i * 600000)).toISOString(),
        })),
    };
};

// Create the store
export const useCommunityStore = create<CommunityState>()(
    persist(
        (set, get) => ({
            posts: [],
            isLoading: false,
            error: null,

            fetchPosts: async (beachId?: string) => {
                set({ isLoading: true, error: null });

                try {
                    // Simulate API call delay
                    await new Promise(resolve => setTimeout(resolve, 1000));

                    // Generate mock posts
                    let mockPosts: CommunityPost[] = [];

                    if (beachId) {
                        // Generate posts for a specific beach
                        mockPosts = Array(10).fill(0).map((_, i) => generateMockPost(beachId, i));
                    } else {
                        // Generate posts for multiple beaches
                        const beachIds = ['beach1', 'beach2', 'beach3', 'beach4', 'beach5'];
                        mockPosts = beachIds.flatMap((id, beachIndex) =>
                            Array(5).fill(0).map((_, i) => generateMockPost(id, beachIndex * 10 + i))
                        );
                    }

                    // Sort by timestamp (newest first)
                    mockPosts.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

                    set({ posts: mockPosts, isLoading: false });
                } catch (error) {
                    console.error('Error fetching posts:', error);
                    set({ error: 'Failed to fetch community posts', isLoading: false });
                }
            },

            addPost: async (postData) => {
                set({ isLoading: true, error: null });

                try {
                    // Simulate API call delay
                    await new Promise(resolve => setTimeout(resolve, 1000));

                    const newPost: CommunityPost = {
                        ...postData,
                        id: `post-${Date.now()}`,
                        timestamp: new Date().toISOString(),
                        likes: 0,
                        comments: [],
                    };

                    set(state => ({
                        posts: [newPost, ...state.posts],
                        isLoading: false,
                    }));
                } catch (error) {
                    console.error('Error adding post:', error);
                    set({ error: 'Failed to add post', isLoading: false });
                }
            },

            likePost: (postId) => {
                set(state => ({
                    posts: state.posts.map(post =>
                        post.id === postId
                            ? { ...post, likes: post.likes + 1 }
                            : post
                    ),
                }));
            },

            addComment: async (commentData) => {
                try {
                    const newComment: CommunityComment = {
                        ...commentData,
                        id: `comment-${Date.now()}`,
                        timestamp: new Date().toISOString(),
                    };

                    set(state => ({
                        posts: state.posts.map(post =>
                            post.id === commentData.postId
                                ? { ...post, comments: [...post.comments, newComment] }
                                : post
                        ),
                    }));
                } catch (error) {
                    console.error('Error adding comment:', error);
                    set({ error: 'Failed to add comment' });
                }
            },

            reportPost: async (postId, reason) => {
                // In a real app, this would send a report to the server
                console.log(`Reported post ${postId} for reason: ${reason}`);
                alert('Post reported. Our moderators will review it shortly.');
            },

            deletePost: async (postId) => {
                set(state => ({
                    posts: state.posts.filter(post => post.id !== postId),
                }));
            },
        }),
        {
            name: 'community-storage',
            storage: createJSONStorage(() => AsyncStorage),
        }
    )
);