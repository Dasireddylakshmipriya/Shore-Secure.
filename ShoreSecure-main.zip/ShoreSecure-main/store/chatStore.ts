import { beaches } from '@/constants/beaches';
import { ChatMessage } from '@/types';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { useBeachStore } from './beachStore';

interface ChatState {
    messages: ChatMessage[];
    isLoading: boolean;
    error: string | null;

    // Actions
    sendMessage: (content: string) => Promise<void>;
    clearChat: () => void;
}

// Extract beach name from user message
const extractBeachName = (message: string): string | null => {
    const beachNames = beaches.map(beach => beach.name.toLowerCase());

    for (const beachName of beachNames) {
        if (message.toLowerCase().includes(beachName)) {
            return beaches.find(beach => beach.name.toLowerCase() === beachName)?.name || null;
        }
    }

    return null;
};

// Check if message is asking about beach safety
const isAskingAboutSafety = (message: string): boolean => {
    const safetyKeywords = ['safe', 'safety', 'dangerous', 'swim', 'swimming', 'danger'];
    return safetyKeywords.some(keyword => message.toLowerCase().includes(keyword));
};

// Check if message is asking about waves
const isAskingAboutWaves = (message: string): boolean => {
    const waveKeywords = ['wave', 'waves', 'swell', 'surf', 'surfing'];
    return waveKeywords.some(keyword => message.toLowerCase().includes(keyword));
};

// Check if message is asking about weather
const isAskingAboutWeather = (message: string): boolean => {
    const weatherKeywords = ['weather', 'temperature', 'wind', 'hot', 'cold', 'rain', 'sunny', 'forecast'];
    return weatherKeywords.some(keyword => message.toLowerCase().includes(keyword));
};

// Generate AI response based on beach data and weather
const generateAIResponse = async (message: string): Promise<string> => {
    const beachName = extractBeachName(message);

    if (!beachName) {
        // Generic responses if no beach is mentioned
        if (isAskingAboutSafety(message)) {
            return "To check if a beach is safe for swimming, please mention the specific beach name. For example, 'Is Calangute Beach safe today?'";
        }

        if (isAskingAboutWaves(message)) {
            return "To get information about wave conditions, please mention the specific beach name. For example, 'How are the waves at Baga Beach today?'";
        }

        if (isAskingAboutWeather(message)) {
            return "To get weather information for a beach, please mention the specific beach name. For example, 'What's the weather like at Kovalam Beach?'";
        }

        return "I'm ShoreBot, your beach safety assistant. I can provide information about beach conditions, safety status, and weather forecasts for beaches across India. Please mention a specific beach name in your question.";
    }

    // Find the beach in our database
    const beach = beaches.find(b => b.name === beachName);

    if (!beach) {
        return `I don't have information about ${beachName}. Please check for a different beach or try again later.`;
    }

    // Get weather data for the beach
    const { weatherData } = useBeachStore.getState();
    const beachWeather = weatherData[beach.id];

    if (!beachWeather) {
        return `I don't have current weather data for ${beachName}. Please try again later or check another beach.`;
    }

    // Generate response based on the query type
    if (isAskingAboutSafety(message)) {
        const safetyStatus = beach.currentSafetyStatus || 'unknown';
        let safetyAdvice = '';

        switch (safetyStatus) {
            case 'safe':
                safetyAdvice = `${beachName} is currently safe for swimming. The conditions are favorable with moderate waves and wind.`;
                break;
            case 'moderate':
                safetyAdvice = `${beachName} currently has moderate risk conditions. Exercise caution while swimming and stay within designated areas.`;
                break;
            case 'dangerous':
                safetyAdvice = `${beachName} is currently not safe for swimming due to dangerous conditions. It's recommended to avoid water activities today.`;
                break;
            default:
                safetyAdvice = `I don't have current safety information for ${beachName}.`;
        }

        return `👋 ${safetyAdvice}\n\n🌊 Wave Height: ${beachWeather.waveHeight.toFixed(1)}m (${beachWeather.waveHeight > 1.5 ? 'High' : beachWeather.waveHeight > 0.5 ? 'Moderate' : 'Low'})\n\n💨 Wind: ${beachWeather.windSpeed.toFixed(1)} km/h from ${beachWeather.windDirection}\n\n🔆 UV Index: ${beachWeather.uvIndex} (${beachWeather.uvIndex > 7 ? 'Very High' : beachWeather.uvIndex > 5 ? 'High' : beachWeather.uvIndex > 2 ? 'Moderate' : 'Low'})\n\n📅 This information is valid as of ${new Date(beachWeather.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.`;
    }

    if (isAskingAboutWaves(message)) {
        return `👋 Here's the current wave information for ${beachName}:\n\n🌊 Wave Height: ${beachWeather.waveHeight.toFixed(1)}m\n\n💨 Wind: ${beachWeather.windSpeed.toFixed(1)} km/h from ${beachWeather.windDirection}\n\n${beachWeather.waveHeight > 1.5 ? 'The waves are quite high today, suitable for experienced surfers.' : beachWeather.waveHeight > 0.5 ? 'The waves are moderate, good for intermediate surfers and swimmers.' : 'The waves are gentle today, perfect for beginners and casual swimming.'}\n\n📅 This information is valid as of ${new Date(beachWeather.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.`;
    }

    if (isAskingAboutWeather(message)) {
        return `👋 Here's the current weather at ${beachName}:\n\n🌡️ Air Temperature: ${beachWeather.temperature.toFixed(1)}°C\n\n🌊 Water Temperature: ${beachWeather.waterTemperature.toFixed(1)}°C\n\n💨 Wind: ${beachWeather.windSpeed.toFixed(1)} km/h from ${beachWeather.windDirection}\n\n🔆 UV Index: ${beachWeather.uvIndex} (${beachWeather.uvIndex > 7 ? 'Very High - Use strong sunscreen' : beachWeather.uvIndex > 5 ? 'High - Use sunscreen' : beachWeather.uvIndex > 2 ? 'Moderate' : 'Low'})\n\n👁️ Visibility: ${beachWeather.visibility}\n\n📅 This information is valid as of ${new Date(beachWeather.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.`;
    }

    // General information about the beach
    return `👋 Here's some information about ${beachName}:\n\n📍 Location: ${beach.location}\n\n🏖️ Description: ${beach.description.substring(0, 100)}...\n\n🚿 Facilities: ${beach.facilities.join(', ')}\n\n🏊 Activities: ${beach.activities.join(', ')}\n\n⏰ Best time to visit: ${beach.bestTimeToVisit}\n\n🔆 Current conditions: ${beach.currentSafetyStatus || 'Unknown'}\n\n📅 This information is valid as of ${new Date().toLocaleString()}.`;
};

// Call AI API for response
const callAI = async (message: string): Promise<string> => {
    // First try to generate a response based on beach data
    const beachResponse = await generateAIResponse(message);
    if (beachResponse) {
        return beachResponse;
    }

    // If no beach-specific response, use the AI API
    if (Platform.OS === 'web') {
        // Simplified mock for web
        return "I'm ShoreBot, your beach safety assistant. I can provide information about beach conditions, safety status, and weather forecasts for beaches across India. Please mention a specific beach name in your question.";
    }

    try {
        const response = await fetch('https://toolkit.rork.com/text/llm/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                messages: [
                    {
                        role: 'system',
                        content: 'You are ShoreBot, an AI assistant for the ShoreSecure beach safety app. You provide helpful information about beach safety, weather conditions, and recommendations for beach activities in India. Keep responses concise and focused on beach safety and tourism in India.'
                    },
                    {
                        role: 'user',
                        content: message
                    }
                ]
            }),
        });

        const data = await response.json();
        return data.completion || "I'm sorry, I couldn't process your request at the moment.";
    } catch (error) {
        console.error('AI API error:', error);
        return "I'm sorry, I'm having trouble connecting to my knowledge base right now. Please try again later.";
    }
};

export const useChatStore = create<ChatState>()(
    persist(
        (set, get) => ({
            messages: [
                {
                    id: '1',
                    role: 'assistant',
                    content: "Hello! I'm ShoreBot, your beach safety assistant. How can I help you today? You can ask me about beach conditions, safety tips, or recommendations for your beach visit in India.",
                    timestamp: new Date().toISOString(),
                }
            ],
            isLoading: false,
            error: null,

            sendMessage: async (content) => {
                const userMessage: ChatMessage = {
                    id: Date.now().toString(),
                    role: 'user',
                    content,
                    timestamp: new Date().toISOString(),
                };

                set(state => ({
                    messages: [...state.messages, userMessage],
                    isLoading: true,
                    error: null,
                }));

                try {
                    const aiResponse = await callAI(content);

                    const assistantMessage: ChatMessage = {
                        id: (Date.now() + 1).toString(),
                        role: 'assistant',
                        content: aiResponse,
                        timestamp: new Date().toISOString(),
                    };

                    set(state => ({
                        messages: [...state.messages, assistantMessage],
                        isLoading: false,
                    }));
                } catch (error) {
                    console.error('Error getting AI response:', error);
                    set({
                        isLoading: false,
                        error: 'Failed to get response from AI'
                    });
                }
            },

            clearChat: () => {
                set({
                    messages: [
                        {
                            id: '1',
                            role: 'assistant',
                            content: "Hello! I'm ShoreBot, your beach safety assistant. How can I help you today? You can ask me about beach conditions, safety tips, or recommendations for your beach visit in India.",
                            timestamp: new Date().toISOString(),
                        }
                    ],
                });
            },
        }),
        {
            name: 'shore-secure-chat',
            storage: createJSONStorage(() => AsyncStorage),
            partialize: (state) => ({
                messages: state.messages.slice(-20), // Only store the last 20 messages
            }),
        }
    )
);