import { EmergencyContact, Trip, User, UserPreferences } from '@/types';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';

interface UserState {
    user: User | null;
    isAuthenticated: boolean;
    isLoading: boolean;
    error: string | null;

    // Auth actions
    login: (email: string, password: string) => Promise<void>;
    logout: () => void;
    register: (name: string, email: string, password: string) => Promise<void>;

    // User data actions
    updateProfile: (data: Partial<User>) => void;
    addEmergencyContact: (contact: Omit<EmergencyContact, 'id'>) => void;
    removeEmergencyContact: (contactId: string) => void;
    saveBeach: (beachId: string) => void;
    unsaveBeach: (beachId: string) => void;
    addTrip: (trip: Omit<Trip, 'id'>) => void;
    removeTrip: (tripId: string) => void;
    updatePreferences: (preferences: Partial<UserPreferences>) => void;
}

// Mock user data for demo purposes
const mockUser: User = {
    id: '1',
    name: 'Demo User',
    email: 'demo@shoresecure.com',
    profilePhoto: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=1000',
    emergencyContacts: [
        { id: '1', name: 'Emergency Contact 1', phone: '+91 9876543210', relationship: 'Family' }
    ],
    savedBeaches: ['1', '4'],
    trips: [
        {
            id: '1',
            beachId: '2',
            startDate: '2025-07-15',
            endDate: '2025-07-20',
            activities: ['Swimming', 'Sunbathing'],
            notes: 'Family vacation'
        }
    ],
    preferences: {
        notificationSettings: {
            safetyAlerts: true,
            weatherUpdates: true,
            tripReminders: true,
        },
        units: 'metric',
        language: 'en',
    }
};

export const useUserStore = create<UserState>()(
    persist(
        (set) => ({
            user: null,
            isAuthenticated: false,
            isLoading: false,
            error: null,

            login: async (email, password) => {
                set({ isLoading: true, error: null });
                try {
                    // In a real app, this would be an API call to authenticate
                    // For demo purposes, we'll use mock data
                    await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay

                    if (email === 'demo@shoresecure.com' && password === 'password') {
                        set({ user: mockUser, isAuthenticated: true, isLoading: false });
                    } else {
                        throw new Error('Invalid credentials');
                    }
                } catch (error) {
                    set({
                        error: error instanceof Error ? error.message : 'Login failed',
                        isLoading: false
                    });
                }
            },

            logout: () => {
                set({ user: null, isAuthenticated: false });
            },

            register: async (name, email, password) => {
                set({ isLoading: true, error: null });
                try {
                    // In a real app, this would be an API call to register
                    await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay

                    const newUser: User = {
                        id: Date.now().toString(),
                        name,
                        email,
                        emergencyContacts: [],
                        savedBeaches: [],
                        trips: [],
                        preferences: {
                            notificationSettings: {
                                safetyAlerts: true,
                                weatherUpdates: true,
                                tripReminders: true,
                            },
                            units: 'metric',
                            language: 'en',
                        }
                    };

                    set({ user: newUser, isAuthenticated: true, isLoading: false });
                } catch (error) {
                    set({
                        error: error instanceof Error ? error.message : 'Registration failed',
                        isLoading: false
                    });
                }
            },

            updateProfile: (data) => {
                set(state => ({
                    user: state.user ? { ...state.user, ...data } : null
                }));
            },

            addEmergencyContact: (contact) => {
                set(state => {
                    if (!state.user) return state;

                    const newContact: EmergencyContact = {
                        ...contact,
                        id: Date.now().toString()
                    };

                    return {
                        user: {
                            ...state.user,
                            emergencyContacts: [...state.user.emergencyContacts, newContact]
                        }
                    };
                });
            },

            removeEmergencyContact: (contactId) => {
                set(state => {
                    if (!state.user) return state;

                    return {
                        user: {
                            ...state.user,
                            emergencyContacts: state.user.emergencyContacts.filter(
                                contact => contact.id !== contactId
                            )
                        }
                    };
                });
            },

            saveBeach: (beachId) => {
                set(state => {
                    if (!state.user) return state;

                    return {
                        user: {
                            ...state.user,
                            savedBeaches: [...state.user.savedBeaches, beachId]
                        }
                    };
                });
            },

            unsaveBeach: (beachId) => {
                set(state => {
                    if (!state.user) return state;

                    return {
                        user: {
                            ...state.user,
                            savedBeaches: state.user.savedBeaches.filter(id => id !== beachId)
                        }
                    };
                });
            },

            addTrip: (trip) => {
                set(state => {
                    if (!state.user) return state;

                    const newTrip: Trip = {
                        ...trip,
                        id: Date.now().toString()
                    };

                    return {
                        user: {
                            ...state.user,
                            trips: [...state.user.trips, newTrip]
                        }
                    };
                });
            },

            removeTrip: (tripId) => {
                set(state => {
                    if (!state.user) return state;

                    return {
                        user: {
                            ...state.user,
                            trips: state.user.trips.filter(trip => trip.id !== tripId)
                        }
                    };
                });
            },

            updatePreferences: (preferences) => {
                set(state => {
                    if (!state.user) return state;

                    return {
                        user: {
                            ...state.user,
                            preferences: {
                                ...state.user.preferences,
                                ...preferences
                            }
                        }
                    };
                });
            },
        }),
        {
            name: 'shore-secure-user',
            storage: createJSONStorage(() => AsyncStorage),
        }
    )
);